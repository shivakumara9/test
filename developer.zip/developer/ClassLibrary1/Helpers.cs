﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Utilities
{
    public static class Extensions
    {
        public static string EncodeUrl(this string source)
        {
            if (string.IsNullOrEmpty(source))
                return "";
            return System.Web.HttpUtility.UrlEncode(source
                                                        .Replace("c#", "c-sharp")
                                                        .Replace("C#", "C-sharp")
                                                        .Replace("#","-sharp-")
                                                        .Replace(" ", "-")
                                                        .Replace("?", "-Q-")
                                                        .Replace(".", "-D-")
                                                        .Replace("=","-Eq-")
                                                        .Replace("&", "-and-")
                                                        );


        }
        public static string DecodeUrl(this string source)
        {
            if (string.IsNullOrEmpty(source))
                source = "";
            source = System.Web.HttpUtility.UrlDecode(source
                                                        .Replace("c-sharp", "c#")
                                                        .Replace("C-sharp", "C#")
                                                        .Replace("-sharp-", "#")
                                                        .Replace("-Q-", "?")
                                                        .Replace("-D-", ".")
                                                        .Replace("-Eq-", "=")
                                                        .Replace("-", " ")
                                                        .Replace("-and-", "&")
                                                        );
            return source;

        }

        public static string EncodeUrl(this object source)
        {
            if (string.IsNullOrEmpty(Convert.ToString(source)))
                return "";

                return System.Web.HttpUtility.UrlEncode(Convert.ToString(source)
                                                            .Replace("c#", "c-sharp")
                                                            .Replace("C#", "C-sharp")
                                                            .Replace(" ", "-")
                                                            .Replace("#","sharp")
                                                            .Replace("&","-and-")
                                                            );
            
            
        }
        public static string DecodeUrl(this object source)
        {
            if (string.IsNullOrEmpty(Convert.ToString(source)))
                source = "";
            source = System.Web.HttpUtility.UrlDecode(Convert.ToString(source)
                                                        .Replace("c-sharp", "c#")
                                                        .Replace("C-sharp", "C#")
                                                        .Replace("-", " ")
                                                        .Replace("sharp","#")
                                                        .Replace("-and-", "&")
                                                        );


            return source.ToString();
        }
    }

}
