using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using System.Web.Mvc;
using System.Web;
using Utilities;

namespace Utilities
{
    public class SqlLibrary
    {
        public static int ExecuteNonQuery(string SqlConnectionstring, string SqlCommand, params object[] Parameters)
        {
            SqlConnection cn = new SqlConnection(SqlConnectionstring);
            cn.Open();
            SqlCommand com = new SqlCommand(SqlCommand, cn);
            com.CommandType = CommandType.StoredProcedure;
            for (int i = 0; i < Parameters.Length; i++)
            {
                SqlParameter sp = new SqlParameter();
                com.Parameters.Add(sp);
                com.Parameters[i].ParameterName = string.Empty;

                if (Parameters[i] == null)
                    com.Parameters[i].Value = DBNull.Value;
                else
                    com.Parameters[i].Value = Parameters[i];
              
            }
          int ret=  com.ExecuteNonQuery();
          cn.Close();
          return ret;
        }

        public static DataSet ExecuteDataSet(string SqlConnectionstring, string SqlCommand,params object[] Parameters)
        {
            SqlConnection cn = new SqlConnection(SqlConnectionstring);
            cn.Open();
            SqlDataAdapter da=new SqlDataAdapter(SqlCommand, cn);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
        
            for (int i = 0; i < Parameters.Length;i++)
            {
                SqlParameter sp=new SqlParameter();
                da.SelectCommand.Parameters.Add(sp);
                da.SelectCommand.Parameters[i].ParameterName = string.Empty;
                if (Parameters[i] == null)
                    da.SelectCommand.Parameters[i].Value = DBNull.Value;
                else
                da.SelectCommand.Parameters[i].Value = Parameters[i];
            }
            DataSet ds = new DataSet();            
            da.Fill(ds);
            cn.Close();
            return ds;
        }

        public static object ExecuteScalar(string SqlConnectionstring, string SqlCommand, params object[] Parameters)
        {
            SqlConnection cn = new SqlConnection(SqlConnectionstring);
            cn.Open();
            SqlCommand com = new SqlCommand(SqlCommand, cn);
            com.CommandType = CommandType.StoredProcedure;
            for (int i = 0; i < Parameters.Length; i++)
            {
                SqlParameter sp = new SqlParameter();
                com.Parameters.Add(sp);
                com.Parameters[i].ParameterName = string.Empty;

                if (Parameters[i] == null)
                    com.Parameters[i].Value = DBNull.Value;
                else
                    com.Parameters[i].Value = Parameters[i];

            }
            object ret = com.ExecuteScalar();
            cn.Close();
            return ret;
        }




    }

    public class pagingController : Controller
    {
       
        public ActionResult GetRecords(string cont, string act, Paging model)
        {
            return RedirectToAction(act, cont, model);
        }
       


    }

    public class Paging
    {
        public int pageno { set; get; }
        public int viewrecords { set; get; }
        public string sortby { set; get; }
        public int count { set; get; }
       // public string cont { set; get; }
       // public string act { set; get; }
        public DataSet GridDataset { set; get; }
        public bool ispagepost { set; get; }
        public string formid { set; get; }
        public string url { set; get; }
        public string GridId { set; get; }
        public string QSConcatinate { set; get; }
        
        public string GetPaging()
        {
            string ht = "";
            if (string.IsNullOrEmpty(QSConcatinate))
                QSConcatinate = "pageno";
            else
                QSConcatinate = QSConcatinate + ".pageno";
            int noofpages = count / viewrecords;
            if (count % viewrecords != 0)
                noofpages += 1;
            if (noofpages > 20)
            {
                if (pageno < 11)
                {
                    for (int i = 1; i <= 20; i++)
                    {
                        if (pageno != i)
                        {
                            ht += "&nbsp;<a href='#' onclick=\""+GridId + "page('" + url + "?"+QSConcatinate+"=" + i + "');\">" + i + "</a>";
                        }
                        else
                        {
                            ht += "&nbsp;" + i;
                        }

                    }
                }
                else if (pageno >= (noofpages - 9))
                {
                    for (int i = noofpages - 19; i <= noofpages; i++)
                    {

                        if (pageno != i)
                        {
                            ht += "&nbsp;<a href='#' onclick=\"" + GridId + "page('" + url + "?" + QSConcatinate + "=" + i + "');\">" + i + "</a>";
                        }
                        else
                        {
                            ht += "&nbsp;" + i;
                        }

                    }
                }
                else
                {
                    for (int i = pageno - 9; i <= pageno - 9 + 19; i++)
                    {

                        if (pageno != i)
                        {
                            ht += "&nbsp;<a href='#' onclick=\"" + GridId + "page('" + url + "?" + QSConcatinate + "=" + i + "');\">" + i + "</a>";
                        }
                        else
                        {
                            ht += "&nbsp;" + i;
                        }

                    }
                }
            }
            else
            {
                for (int i = 1; i <= noofpages; i++)
                {
                    if (pageno != i)
                    {
                        ht += "&nbsp;<a href='#' onclick=\"" + GridId + "page('" + url + "?" + QSConcatinate + "=" + i + "');\">" + i + "</a>";
                    }
                    else
                    {
                        if (noofpages > 1)
                            ht += "&nbsp;" + i;
                    }

                }
            }


            return ht;
        }

        public string GetHeader(params Object[] ColumnNames)
        {
            string ht = "";
            foreach (string[] column in ColumnNames)
            {
                if (sortby.Contains(column[1]))
                {
                    if (sortby.Contains("desc"))
                        ht += "<th class='griddesc' val=\"" + column[1] + "\">" + column[0] + "</th>";
                    else
                        ht += "<th class='gridasc' val=\"" + column[1] + " desc\">" + column[0] + "</th>";
                }
                else
                {
                    ht += "<th val=\"" + column[1] + "\">" + column[0] + "</th>";
                }
            }
            return ht;
        }


        public string GetTableScript(string GridId, int PagestartFrom, int ViewRecords, string SortBy)
        {
            if (!string.IsNullOrEmpty(QSConcatinate))
                QSConcatinate = QSConcatinate + ".";
            string Root = HttpContext.Current.Request.ApplicationPath;
            sortby = SortBy;
            this.GridId = GridId;
          //  cont = ControllerName;
            //act = Action;
            pageno = PagestartFrom;
            viewrecords = ViewRecords;
            string HTMl = "";
            HTMl += "<script type='text/javascript'>";
            HTMl += "function " + GridId + "page(url) {";
            if (ispagepost)
            {
                HTMl += formid != null ? "$('#" + formid + "').attr('action','" + Root + "'+url).submit();" : "$('form').attr('action','" + Root + "'+url).submit();";
                HTMl += "setCookie('coo',1);";
            }
            else
            {
                HTMl += "$.ajax({";
                HTMl += "url: '" + Root + "' + url,";
                HTMl += "type: 'POST',";
                HTMl += "cache: false,";
                HTMl += "data: $('#" + GridId + "_PageForm').serialize(),";
                HTMl += "success: function (result) {";
                HTMl += "$('#" + GridId + "_Container').html(result);";
                HTMl += "},";
                HTMl += "error: function (request, status, error) {";
                HTMl += "}";
                HTMl += "});";
            }
                HTMl += "}";
            
            HTMl += "</script>";
            HTMl += ispagepost == false ? "<form id='" + GridId + "_PageForm'>" : "";
            HTMl += "<input type='hidden' value='" + viewrecords + "' name='" + QSConcatinate + "viewrecords'/>";
            HTMl += "<input type='hidden' value='" + sortby + "' name='" + QSConcatinate + "sortby'/>";
            HTMl += "<input type='hidden' value='" + count + "' name='" + QSConcatinate + "count'/>";          
            HTMl += ispagepost == false ? "</form>" : "";

            return HTMl;
        }



    }
}
