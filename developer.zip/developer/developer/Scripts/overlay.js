﻿$(document).ready(function () {
    $('.close').click(function () {
        overlayclose();
    });
});
var showOverlay = function (headertext, content) {
    $('#page').css('opacity', '0.4');
    $('#overlay-content').show();
    $('#overlay-content .header').append(headertext);
    $('#overlay-content #overlaycontent').html(content);

}

function overlayclose() {
    $('#overlay-content').hide();
    $('#page').css('opacity', '1');
    $('#overlay-content #overlaycontent').html('');
}