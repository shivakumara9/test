﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using developer.Areas.Articles.Models;
using Utilities;
namespace developer.Areas.Articles.Controllers
{
    public class defaultController : Controller
    {
        //
        // GET: /Articles/kk/

        public ActionResult Index(string name, string id, Article model)
        {
             name=name.DecodeUrl();
             id=id.DecodeUrl();
           // default model = new default();
            if (WebInfo.IsNumeric(id))
            {
                model.ArticleId = Convert.ToInt32(id);
                model.Load();
                model.GetComments();
               // ViewData["user"] = User.Identity.Name;
                return View("Articles", model);
            }
            else
            {
                if (string.IsNullOrEmpty(name))
                {
                    model.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
                    model.LoadCatGrid();
                    model.ispagepost = true;
                    model.formid = "AllArticlesform";
                    model.url = "Articles";
                    
                                     
                    return View("AllArticles", model);
                }
                else if (string.IsNullOrEmpty(id))
                {
                  //  new Lookup().GetLookupOnTypeNRel("Category",name);
                    model.Category = name;
                    model.CategoryList = new developer.Models.Lookup().GetLookupOnTypeNRel("Category", name);
                    if (model.CategoryList.Count <= 0)
                    {
                        WebInfo.Throw404Error();
                        return null;
                    }

                    model.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
                    model.LoadCatGrid();
                    model.ispagepost = true;
                    model.formid = "Articlesoncatform";
                    model.url = "Articles/" + name;
                    return View("ArticlesOnCat", model);
                }
                else
                {
                    model.Category = name;
                    model.SubCategory = id;
                    model.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
                    model.LoadCatGrid();
                    model.ispagepost = true;
                    model.formid = "Articlesonsubcatform";
                    model.url = "Articles/" + name + "/" + id;    
                    return View("ArticlesOnSubCat", model);
                }
                
            }
            
        }

      

       

    }
}
