﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using Utilities;
namespace developer.Areas.Member.Controllers
{
    public class MemberController : pagingController
    {
        //
        // GET: /Member/Home/

        [Authorize]
        public ActionResult Index(developer.Models.Member model)
        {
            
            
            model.DashBoardLoad();

            model.pageno = model.pageno == 0 ? 1 : model.pageno;
            model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;     
            model.GetAllLatestUpades();
            model.url = "Member";
            model.ispagepost = true;
            model.UserName = User.Identity.Name;
            model.formid = "MemberForm";

            model.Memberdetails();
            return View(model);
        }
        public ActionResult MyArticles()
        {
            developer.Models.Article model = new Models.Article();
            model.UserName = User.Identity.Name;
            model.viewrecords = 10;
            model.pageno = 1;
            
            return View(model);
        }

        public ActionResult MyQuestions()
        {
            developer.Models.Forum model = new Models.Forum();
            model.UserName = User.Identity.Name;
            model.viewrecords = 10;
            model.pageno = 1;

            return View(model);
        }

        public ActionResult EditArticle(int id, int? Updated)
        {
            Article model = new Article();
            model.ArticleId = id;
            model.Load();
            if (Updated == 1)
                ViewData["updated"] = 1;
            return View("AddArticle", model);
        }

        public ActionResult AddArticle()
        {
            Article model = new Article();   
            return View(model);
        }

        public ActionResult AddForum()
        {
            Forum model = new Forum();
            return View(model);
        }

        public int DeleteArticle(int id)
        {
            Article model = new Article();
            model.ArticleId = id;
            return model.Delete();
        }
        

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult AddArticle(Article model)
        {
            ModelState.Clear();
            //Article model = new Article();
            if (ModelState.IsValid)
                ViewData["updated"] =1;
            model.ArticleId=model.Update(null);
            return RedirectToAction("EditArticle", "Member", new { Id = model.ArticleId,Updated=1 });
        }


        [HttpPost]
        [ValidateInput(false)]
        public ActionResult AddArticleSubmit(Article model)
        {
            //Article model = new Article();
            if (ModelState.IsValid)
                ViewData["updated"] = 1;
            model.ArticleId = model.Update("pending");

            return View("Publishsuccess", model);
           // return View("AddArticle", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult AddForumSubmit(Forum model)
        {
            //Article model = new Article();
            if (ModelState.IsValid)
                ViewData["updated"] = model.Update();
            // new SMS().SendSMS("Forum has been added in" + model.SubCategory + " sub category" + "title:" + model.Title);
           
            return View("ForumForm", model);
        }




        public JsonResult GetImages(string[] imgsarr)
        {
            if (imgsarr != null)
            {
                for (int i = 0; i < imgsarr.Length; i++)
                {
                    imgsarr[i] = imgsarr[i].Substring(imgsarr[i].IndexOf("base64,"));
                    imgsarr[i] = imgsarr[i].Replace("base64,", "");
                    byte[] data = Convert.FromBase64String(imgsarr[i]);
                    Article ar = new Article();
                    imgsarr[i] = ar.SaveImage(data);

                }
            }
            return Json(imgsarr);

        }

        public ActionResult GetTableHtml(developer.Models.Member model)
        {
            model.UserName = User.Identity.Name;
            model.Load();
            return View("table", model);
        }

        public ActionResult GetlatestUpdatesTableHtml(developer.Models.Member model)
        {
          
            model.GetAllLatestUpades();
            return View("LatestUpdates", model);
        }
        public ActionResult MyAlerts()
        {
            developer.Models.Member model = new Models.Member();
            model.pageno = 1;
            model.viewrecords = 10;
            model.MyAlertGrid();
            return View(model);
        }

        public ActionResult GetAlertTable(developer.Models.Member model)
        {
            model.MyAlertGrid();
            return View(model);
        }


        [HttpPost]
        public bool UpdateAlert(int id)
        {
            if (!string.IsNullOrEmpty(Convert.ToString(Request.Headers["X-Requested-With"])))
            {
                developer.Models.Member model = new Models.Member();
                model.UpdateAlertStatus(id);
            }
            return true;
        }
        
        [HttpPost]
        [ValidateInput(false)]
        public ActionResult PostComment(int ? id,Comment model)
        {
           model.UserName = User.Identity.Name;
           model.PostComment();

           Article Amodel = new Article();
           Amodel.ArticleId = Convert.ToInt32(id);
           Amodel.Load();
           Amodel.GetComments();
           return View("~/Areas/Articles/Views/default/Articles.aspx", Amodel);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult PostForumComment(Comment model)
        {
           model.UserName = User.Identity.Name;
           
           model.PostForumComment();
           return View("Comment",model);
        }


        
        public ActionResult UploadImage()
        {
            developer.Models.Member model = new Models.Member();
            return View(model);
        }

        [HttpPost]
        public ActionResult UploadImage(developer.Models.Member model)
        {
            if (Request.Files.Count > 0)
            {
                int length = Request.Files[0].ContentLength;
               
                System.IO.MemoryStream stream=new System.IO.MemoryStream();
                System.Drawing.Image image = new ImageResize().GetImage(113,100, Request.Files[0].InputStream);
                image.Save(stream, System.Drawing.Imaging.ImageFormat.Jpeg);
                
                //byte[] byt = new byte[stream.Length];
                //stream.Read(byt, 0, byt.Length);
                model.Image = stream.ToArray();
                model.UserName = User.Identity.Name;
                if (model.UpdateImage() == 1)
                    ViewData["imageupdated"] = 1;
            }
            return View("index",model);
        }


        //Admin role
        [RoleFilter(RoleName = "Reviewer")]
        public ActionResult ReviewArticles()
        {
            Article model = new Article();
            return View("ReviewArticles", model);
        }

        
        public ActionResult RejectedOnId(int id)
        {
            Article model = new Article();
            model.ArticleId = id;
            model.Load();
            return View("RejectedOnId", model);
        }

        //Admin role
        [RoleFilter(RoleName = "Reviewer")]
        public ActionResult ReviewOnId(int id)
        {
            Article model = new Article();
            model.ArticleId = id;
            model.Load();
            return View("ReviewArticle", model);
        }
        [RoleFilter(RoleName = "Reviewer")]
        public ActionResult ApproveRejectArticle(int ArticleId, string Response, string StatusKey)
        {
            Article model = new Article();
            model.ArticleId = ArticleId;
            model.Load();
            model.InsertResponse(ArticleId,Response, StatusKey);
            ModelState.Clear();
            if (StatusKey == "accepted")
                ViewBag.Status = "This Article has been Approved";
            else
                ViewBag.Status = "This Article has been Rejected";
            return View("ReviewArticle", model);
        }
        [HttpGet]
        [RoleFilter(RoleName = "SuperAdmin")]
        public ActionResult AddReviewer()
        {
            developer.Models.Member model = new developer.Models.Member();            
            return View("AddReviewer", model);
        }

        [HttpPost]
        [RoleFilter(RoleName = "SuperAdmin")]
        public ActionResult AddReviewer(developer.Models.Member model)
        {
            model.AddReviewer();
            return View("AddReviewer", model);
        }

        public ActionResult Dashboard()
        {
            developer.Models.Member model = new developer.Models.Member();
            return View(model);
        }
        

    }
}
