﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using developer.Areas.Articles.Models;
using Utilities;
namespace developer.Areas.Forums.Controllers
{
    public class defaultController : Controller
    {
        //
        // GET: /Articles/kk/

        public ActionResult Index(string name, string id, Forum model)
        {
            name=name.DecodeUrl();
            id=id.DecodeUrl();
           // Default model = new Default();
            if (WebInfo.IsNumeric(id))
            {
                model.ForumId = Convert.ToInt32(id);
                model.Load();
                model.GetComments();
               // ViewData["user"] = User.Identity.Name;
                return View("Forums", model);
            }
            else
            {
                if (string.IsNullOrEmpty(name))
                {
                    model.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
                    model.LoadCatGrid();
                    model.ispagepost = true;
                    model.formid = "Allforumsform";
                    model.url = "Forums";
                    
                    return View("AllForums", model);
                }
                else if (string.IsNullOrEmpty(id))
                {
                  //  new Lookup().GetLookupOnTypeNRel("Category",name);
                    model.Category = name;
                    model.CategoryList = new developer.Models.Lookup().GetLookupOnTypeNRel("Category", name);
                    if (model.CategoryList.Count <= 0)
                    {
                        WebInfo.Throw404Error();
                        return null;
                    }
                    model.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
                    model.LoadCatGrid();
                    model.ispagepost = true;
                    model.formid = "Forumsoncatform";
                    model.url = "Forums/"+name;
                    return View("ForumsOnCat", model);
                }
                else
                {
                    model.Category = name;
                    model.SubCategory = id;
                    model.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
                    model.LoadCatGrid();
                    model.ispagepost = true;
                    model.formid = "Forumsonsubcatform";
                    model.url = "Forums/"+name+"/"+id;                    
                    
                    return View("ForumsOnSubCat", model);
                }
                
            }
            
        }

      

       

    }
}
