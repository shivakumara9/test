﻿using System.Web.Mvc;

namespace developer.Areas.Forums
{
    public class ForumsAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Forums";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Forums_default",
                "Forums/{name}/{id}",
               new { controller = "default", action = "Index", name = UrlParameter.Optional, id = UrlParameter.Optional } // Parameter defaults
            );
        }
    }
}
