﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;

namespace developer.Areas.Tools.Controllers
{
    public class StringFunctionsController : Controller
    {
        //
        // GET: /Tools/StringLength/
        public ActionResult index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult StringLength()
        {
            StringLength model = new StringLength();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult StringLength(StringLength model)
        {
            model.Calc();
            return View(model);
        }


        [HttpGet]
        public ActionResult ReverseString()
        {
            StringLength model = new StringLength();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ReverseString(StringLength model)
        {
            ModelState.Clear();
            model.Reverse();
            return View(model);
        }

        [HttpGet]
        public ActionResult ConvertCase()
        {
            StringLength model = new StringLength();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult ConvertCase(StringLength model)
        {
            ModelState.Clear();
            model.ConvertCase();
            return View(model);
        }



        [HttpGet]
        public ActionResult WordCount()
        {
            StringLength model = new StringLength();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult WordCount(StringLength model)
        {
            ModelState.Clear();
            model.WordCount();
            return View(model);
        }

        [HttpGet]
        public ActionResult HtmlEncode()
        {
            StringLength model = new StringLength();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult HtmlEncode(StringLength model)
        {
            ModelState.Clear();
            model.HtmlEncode();
            return View(model);
        }

        [HttpGet]
        public ActionResult HtmlDecode()
        {
            StringLength model = new StringLength();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult HtmlDecode(StringLength model)
        {
            ModelState.Clear();
            model.Htmldecode();
            return View(model);
        }


        [HttpGet]
        public ActionResult HextoRGB()
        {
            StringLength model = new StringLength();
            return View(model);
        }

        [HttpPost]        
        public ActionResult HextoRGB(StringLength model)
        {
            ModelState.Clear();
            model.HextoRGB();
            return View(model);
        }
    }
}
