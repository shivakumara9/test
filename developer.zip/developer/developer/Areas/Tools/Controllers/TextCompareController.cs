﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
namespace developer.Areas.Tools.Controllers
{
    public class TextCompareController : Controller
    {
        //
        // GET: /Tools/TextCompare/

        [HttpGet]
        public ActionResult Index()
        {
            TextCompare model = new TextCompare();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Index(TextCompare model)
        {
            ModelState.Clear();
            if (model.Result == 0)
                model.Compare();
            else
                model.Result = 0;
            return View(model);
        }
    }
}
