﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace developer.Areas.Tools.Controllers
{
    public class defaultController : Controller
    {
        //
        // GET: /Tools/default/

        public ActionResult Index()
        {
            return View();
        }

    }
}
