﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
namespace developer.Areas.User.Controllers
{
    public class UserController : Controller
    {
        //
        // GET: /User/User/

        public ActionResult Index(string UserName,developer.Models.User model)
        {
            if (string.IsNullOrEmpty(UserName))
            {
                //WebInfo.Throw404Error();

                return View("UsersList",model.UsersList());
            }             
            model.UserName = UserName;
            if (model.GetUserDetails() != 1)
            {
                WebInfo.Throw404Error();
            }
            else
            {
                model.pageno = model.pageno == 0 ? 1 : model.pageno;
                model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
                model.formid = "UserForm";
                
                model.ispagepost = true;
                if (model.UserTabs == null || model.UserTabs.ActiveTabId == 1)
                {
                      model.GetUserLatestUpdates();
                }
                else if (model.UserTabs.ActiveTabId == 2)
                {
                    model.UserArticles.UserName = UserName;
                    model.UserArticles.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.UserArticles.viewrecords = model.UserArticles.viewrecords == 0 ? 10 : model.UserArticles.viewrecords;
                    model.UserArticles.GetArticleOnUser();
                }

                else if (model.UserTabs.ActiveTabId == 3)
                {

                    model.UserForum.UserName = UserName;
                    model.UserForum.pageno = model.pageno == 0 ? 1 : model.pageno;
                    model.UserForum.viewrecords = model.UserForum.viewrecords == 0 ? 10 : model.UserForum.viewrecords;
                    model.UserForum.GetForumsOnUser();
                }
            }
            return View("User",model);
        }

       

    }
}
