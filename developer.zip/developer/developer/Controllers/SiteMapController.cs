﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using System.Xml.Serialization;
using Utilities;
using System.Configuration;
using System.Data;
using Utilities;
namespace developer.Controllers
{
    public class SiteMapController : Controller
    {
        //
        // GET: /SiteMap/
        public string HostUrl { set; get; }
        public SiteMapController()
        {
            HostUrl = "http://devchips.com";
        }

        public ActionResult devchipsSiteMapIndex()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Sitemap_Get_SIteMapindex");
            SitemapIndex sitemap = new SitemapIndex();
            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    sitemap.Add(new Sitemaps()
                    {
                        Url = HostUrl + "/SiteMap/" + (Convert.ToString(dr["type"]) == "Articles" ? "Articles" : "Forums") + "/" + Convert.ToString(dr["Category"]).EncodeUrl(),
                        LastModified = Convert.ToString(dr["lastmoddate"])
                    });
                }
            }
            Response.Clear();
            XmlSerializer xs = new XmlSerializer(typeof(SitemapIndex));
            Response.ContentType = "text/xml";
            xs.Serialize(Response.Output, sitemap);
            Response.End();

            //
            return View();
        }

        public ActionResult Articles(string Category)
        {
            if (!string.IsNullOrEmpty(Category))
            {

                //

                DataSet ds =SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Articles_Get_Sitemap", Category);
                Sitemap sitemap = new Sitemap();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        sitemap.Add(new Location()
                        {
                            Url = HostUrl + "/Articles/" + Convert.ToString(dr["title"]).EncodeUrl() +"/"+ Convert.ToString(dr["id"]),
                            LastModified = Convert.ToString(dr["lastmodified"])
                        });
                    }
                }
                
                // In MVC you would just return an XmlReturn, in WebForms
                // you can do this...
                Response.Clear();
                XmlSerializer xs = new XmlSerializer(typeof(Sitemap));
                Response.ContentType = "text/xml";
                xs.Serialize(Response.Output, sitemap);
                Response.End();

                
            }
            else
            {
                WebInfo.Throw404Error();
            }
            return null;

        }
        public ActionResult Forums(string Category)
        {
            if (!string.IsNullOrEmpty(Category))
            {

                //

                DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Forums_Get_Sitemap", Category);
                Sitemap sitemap = new Sitemap();
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        sitemap.Add(new Location()
                        {
                            Url = HostUrl + "/Forums/" + Convert.ToString(dr["title"]).EncodeUrl() + "/" + Convert.ToString(dr["id"]),
                            LastModified = Convert.ToString(dr["lastmodified"])
                        });
                    }
                }

                // In MVC you would just return an XmlReturn, in WebForms
                // you can do this...
                Response.Clear();
                XmlSerializer xs = new XmlSerializer(typeof(Sitemap));
                Response.ContentType = "text/xml";
                xs.Serialize(Response.Output, sitemap);
                Response.End();


            }
            else
            {
                WebInfo.Throw404Error();
            }
            return null;

        }

    }
}
