﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data;

namespace developer.Models
{
    public class Menu
    {
        public int Id { set; get; }
        public string Category { set; get; }
        public List<Menu> SubCategoriesList { set; get; }
        private List<Menu> CategoriesList { set; get; }
        public Menu()
        {
        }
        public Menu(String k)
        {
            if (HttpContext.Current.Session["Menu"] == null)
            {
                DataSet ds= Utilities.SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_Menu");
                CategoriesList = new List<Menu>();                
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Menu Categories = new Menu();
                    Categories.Category = Convert.ToString(dr["lookuptext"]);
                    Categories.Id = Convert.ToInt32(dr["id"]);
                    Categories.SubCategoriesList  = new List<Menu>();
                    foreach (string Subcategory in Convert.ToString(dr["Sucategories"]).Split(','))
                    {
                        Menu SubCategories = new Menu();
                        SubCategories.Category = Subcategory.Split(':')[0];
                        SubCategories.Id =Convert.ToInt32(Subcategory.Split(':')[1]);
                        Categories.SubCategoriesList.Add(SubCategories);
                    }
                    CategoriesList.Add(Categories);
                }
                HttpContext.Current.Session["Menu"] = CategoriesList;
            }
        }

    }
}