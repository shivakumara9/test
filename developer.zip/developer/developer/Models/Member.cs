﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
namespace developer.Models
{
    public class Member : Paging
    {
        public int AlertCount { set; get; }
        public long userid { set; get; }
        public string UserName { set; get; }
        public string Role { set; get; }
        public byte[] Image { set; get; }
        public string LevelKey { set; get; }
        public DataSet MemberDs { set; get; }
        public string Credits { set; get; } 
      
        public void Load()
        {
            if (sortby == null)
                sortby = "";
            GridDataset = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_user_Articles", viewrecords, pageno, sortby,UserName);
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
        }

        public void DashBoardLoad()
        {
            userid = 1;
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_DashBoard", userid);
            if (ds.Tables[0].Rows.Count > 0)
            {
                AlertCount = Convert.ToInt32(ds.Tables[0].Select("DashBoarditem='Alerts'")[0]["count"]);
            }
        }

        public void MyAlertGrid()
        {
            userid = 1;
            if (sortby == null)
                sortby = "";
            GridDataset = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Grid_alerts", viewrecords, pageno, sortby, userid);
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
        }
        public void UpdateAlertStatus(int id)
        {
            SqlLibrary.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Update_alertstatus", id);
        }

        public int UpdateImage()
        {
            SqlConnection cn = new SqlConnection(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString);
            cn.Open();
            SqlCommand com = new SqlCommand("userimage_update", cn);
            com.CommandType = CommandType.StoredProcedure;
            SqlParameter p1=new SqlParameter("username", SqlDbType.VarChar);
            p1.Value = UserName;
            SqlParameter p2 = new SqlParameter("image", SqlDbType.Image);
            p2.Value = Image;
            com.Parameters.Add(p1);
            com.Parameters.Add(p2);
            com.ExecuteNonQuery();
            return 1;
            //return SqlLibrary.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "userimage_update", UserName, Image);
        }

        public void GetAllLatestUpades()
        {
            if (sortby == null)
                sortby = "";
            GridDataset = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetAllLatestUpdates",viewrecords, pageno, sortby);
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
        }

        public void Memberdetails()
        {
            MemberDs = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetMemberdetails",UserName);
            if (MemberDs.Tables[0].Rows.Count > 0)
            {
                LevelKey = MemberDs.Tables[0].Rows[0]["LevelKey"].ToString();
                Credits = MemberDs.Tables[0].Rows[0]["TotalCredits"].ToString();
            }
            else
            {
                LevelKey = "";
                Credits = "0";
            }
            
        }

        public DataTable GetAllReviewers()
        {
            return SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetAllReviewers").Tables[0];
        }

        internal void AddReviewer()
        {
            SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "AddReviewers", UserName, Role);
        }
    }
}