﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities;
using System.Configuration;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Security.AccessControl;

namespace developer.Models
{
    public class Forum:Paging
    {
        [Required(ErrorMessage = "Please select Category")]
        [DisplayName("Category")]
        public int CategoryId { set; get; }
        [Required(ErrorMessage = "Please select SubCategory")]
        [DisplayName("Sub Category")]
        public int SubCategoryId { set; get; }

        public int ForumId { set; get; }
        [Required(ErrorMessage="Please enter Title")]
        public string Title { set; get; }
        [Required(ErrorMessage = "Please enter Summary")]
        public string Summary { set; get; }
        [Required(ErrorMessage = "Please enter Keywords")]
        public string Keywords { set; get; }
        public int Credits { set; get; }
        public int Rs { set; get; }
        [Required(ErrorMessage = "Please enter Content")]
        public string Content { set; get; }
        public string CreatedBy { get; set; }
        public string CreatedDate { get; set; }
        public string UpdatedDate { get; set; }
        public List<Comment> CommentList { set; get; }
        public string Response { set; get; }
        public string StatusKey { set; get; }
        public string Category { set; get; }
        public string SubCategory { set; get; }
        public List<Lookup> CategoryList { set; get; }
        public List<Lookup> SubCategoryList { set; get; }
        public string UserName { set; get; }
        public bool Load()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_ForumDetails", ForumId);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Title = ds.Tables[0].Rows[0]["title"].ToString();                
                Keywords = ds.Tables[0].Rows[0]["keywords"].ToString();
                //  Credits = Convert.ToInt32(ds.Tables[0].Rows[0]["Credits"].ToString());
                //  Rs =Convert.ToInt32( ds.Tables[0].Rows[0]["Rs"].ToString());
                Content = ds.Tables[0].Rows[0]["Content"].ToString();
                // CreatedBy = ds.Tables[0].Rows[0]["CreatedBy"].ToString();
                // CreatedDate = ds.Tables[0].Rows[0]["CreatedDate"].ToString();
                CategoryId = Convert.ToInt32(ds.Tables[0].Rows[0]["categoryid"].ToString());
                SubCategoryId = Convert.ToInt32(ds.Tables[0].Rows[0]["subcategoryid"].ToString());
                CreatedBy = ds.Tables[0].Rows[0]["username"].ToString();
                CreatedDate = DateTime.Now.ToString("dd/MM/yyyy");
                StatusKey = ds.Tables[0].Rows[0]["statuskey"].ToString();
                return true;
            }
            else
                return false;


        }

        public int Update()
        {
            return SqlLibrary.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Update_Forum", ForumId, Title, Summary, Keywords, Content, SubCategoryId, "pending", HttpContext.Current.User.Identity.Name);
        }

        public int Delete()
        {
            return SqlLibrary.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Delete_Forum", ForumId);
        }

        public string SaveImage(byte[] Image)
        {
            string filename = CreateImageName(HttpContext.Current.Request.PhysicalApplicationPath + "Images");
            SetwritepermitionstoaFolder(HttpContext.Current.Request.PhysicalApplicationPath + "Images");
            File.WriteAllBytes(HttpContext.Current.Request.PhysicalApplicationPath + "Images\\" + filename, Image);
            return "Images/" + filename;
        }

        public string CreateImageName(string filepath)
        {
            return "Image-"+(Directory.GetFiles(filepath).Length + 1).ToString()+".png";
        }

        public void SetwritepermitionstoaFolder(string path)
        {
            // Create a new DirectoryInfo object corresponding to the remote folder.
            DirectoryInfo dirInfo = new DirectoryInfo(path);

            // Get a DirectorySecurity object that represents the current security settings.
            DirectorySecurity dirSecurity = dirInfo.GetAccessControl();

            string user = "Everyone";

            // add the write rule for the remote directory
            dirSecurity.AddAccessRule(new FileSystemAccessRule(user, FileSystemRights.Write, AccessControlType.Allow));

            // Set the new access settings.
            dirInfo.SetAccessControl(dirSecurity);
        }


        public List<Comment> GetComments()
        {
            CommentList = new List<Comment>();
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "ForumResponcesOnForumid", ForumId);
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                Comment com = new Comment();
                com.id = Convert.ToInt32(ds.Tables[0].Rows[i]["id"]);
                com.Credits = Convert.ToInt32(ds.Tables[0].Rows[i]["Credits"]);
                com.Response = ds.Tables[0].Rows[i]["response"].ToString();
                com.UserName = ds.Tables[0].Rows[i]["username"].ToString();
                com.Createddate = ds.Tables[0].Rows[i]["Createddate"].ToString();
                CommentList.Add(com);


            } 
            
            return CommentList;
        }

        public List<Lookup> GetAllCategories()
        {
           return new Lookup().GetLookupOnType("Category");
        }

        public List<Lookup> GetAllSubCategories(int catid)
        {
            return new Lookup().GetLookupOnTypeNRel("SubCategory", catid);
        }


        public void LoadCatGrid()
        {
            string category="",type="";
            if (!string.IsNullOrEmpty(SubCategory))
            {
                category = SubCategory;
                type = "SubCategory";
            }
            else if (!string.IsNullOrEmpty(Category))
            {
                category = Category;
                type = "Category";
            }
            else
            {
                category = "";
                type = "";
            }
             if (sortby == null)
                sortby = "";
             GridDataset = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Grid_ForumsOnCategory", viewrecords, pageno, sortby, category, type);
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
            
        }

        public void GetForumsOnUser()
        {

            if (sortby == null)
                sortby = "";
            GridDataset = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_user_Forums", viewrecords, pageno, sortby, UserName);
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
        }


        public DataTable GetAllPendingQuestions()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_AllPendingQuestions");
            return ds.Tables[0];

        }

        public DataTable GetAllSavedQuestions()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetAllSavedQuestions");
            return ds.Tables[0];

        }
        public DataTable GetAllApprovedQuestions()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetAllApprovedQuestions");
            return ds.Tables[0];

        }
        public DataTable GetAllRejectedQuestions()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetAllRejectedQuestions");
            return ds.Tables[0];

        }
      
    }
}
