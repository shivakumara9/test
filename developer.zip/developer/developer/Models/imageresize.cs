﻿using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

/// <summary>
/// Summary description for imageresize
/// </summary>
/// 
namespace developer.Models
{
    public class ImageResize
    {
        public ImageResize()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        private bool ThumbnailCallback()
        {
            return false;
        }
        public System.Drawing.Image GetImage(int W_or_H, System.IO.Stream stream)
        {
            int targetH, targetW;
            System.Drawing.Image.GetThumbnailImageAbort myCallback = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
            System.Drawing.Bitmap myBitmap = new System.Drawing.Bitmap(stream);
            if (myBitmap.Width < myBitmap.Height)
            {
                targetH = W_or_H;

                targetW = (int)(myBitmap.Width * ((float)targetH / (float)myBitmap.Height));
            }
            else
            {
                targetW = W_or_H;

                targetH = (int)(myBitmap.Height * ((float)targetW / (float)myBitmap.Width));
            }
            System.Drawing.Image myThumbnail = myBitmap.GetThumbnailImage(targetW, targetH, myCallback, IntPtr.Zero);
            
            return myThumbnail;
        }



        public System.Drawing.Image GetImage(int width,int Height, System.IO.Stream stream)
        {
            int targetH, targetW;
            System.Drawing.Image.GetThumbnailImageAbort myCallback = new System.Drawing.Image.GetThumbnailImageAbort(ThumbnailCallback);
            System.Drawing.Bitmap myBitmap = new System.Drawing.Bitmap(stream);
            if (myBitmap.Width < myBitmap.Height)
            {
                targetH = Height;

                targetW = (int)(myBitmap.Width * ((float)targetH / (float)myBitmap.Height));
            }
            else
            {
                targetW = width;

                targetH = (int)(myBitmap.Height * ((float)targetW / (float)myBitmap.Width));
            }
            System.Drawing.Image myThumbnail = myBitmap.GetThumbnailImage(targetW, targetH, myCallback, IntPtr.Zero);
            return myThumbnail;
        }
    }
}