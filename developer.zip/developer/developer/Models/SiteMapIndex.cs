﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml.Serialization;
using System.Collections;

namespace developer.Models
{
    [XmlRoot("sitemapindex", Namespace = "http://www.sitemaps.org/schemas/sitemap/0.9")]
    public class SitemapIndex
    {
        private ArrayList map;


        public SitemapIndex()
        {
            map = new ArrayList();
        }


        [XmlElement("sitemap")]
        public Sitemaps[] Sitemaps
        {
            get
            {
                Sitemaps[] items = new Sitemaps[map.Count];
                map.CopyTo(items);
                return items;
            }
            set
            {
                if (value == null)
                    return;
                Sitemaps[] items = (Sitemaps[])value;
                map.Clear();
                foreach (Sitemaps item in items)
                    map.Add(item);
            }
        }

        public int Add(Sitemaps item)
        {
            return map.Add(item);
        }
    }

    // Items in the shopping list
    public class Sitemaps
    {
        public enum eChangeFrequency
        {
            always,
            hourly,
            daily,
            weekly,
            monthly,
            yearly,
            never
        }

        [XmlElement("loc")]
        public string Url { get; set; }

        [XmlElement("changefreq")]
        public eChangeFrequency? ChangeFrequency { get; set; }
        public bool ShouldSerializeChangeFrequency() { return ChangeFrequency.HasValue; }

        [XmlElement("lastmod")]
        public String LastModified { get; set; }
        public bool ShouldSerializeLastModified() { return !String.IsNullOrEmpty(LastModified); }

        [XmlElement("priority")]
        public double? Priority { get; set; }
        public bool ShouldSerializePriority() { return Priority.HasValue; }
    }
}