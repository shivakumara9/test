﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities;
using System.Configuration;
using System.Data;
namespace developer.Models
{
    public class Comment
    {

        public string UserName { set; get; }
        public int Credits { set; get; }
        public string Response { set; get; }
        public string Createddate { set; get; }
        public int ArticleId { set; get; }
        public int id { set; get; }
        public int ForumId { set; get; }
        public int PostComment()
        {
            if (Response.Length > 2000)
                Response = Response.Substring(0, 2000);
            DataSet ds= SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "PostArticleComment", ArticleId, UserName, Response);
            Credits = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
            Createddate = ds.Tables[0].Rows[0][1].ToString();
            id = Convert.ToInt32(ds.Tables[0].Rows[0][2]);
            return 1;
        }


        public int PostForumComment()
        {
            if (Response.Length > 2000)
                Response = Response.Substring(0, 2000);
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "PostForumComment", ForumId, UserName, Response);
            Credits = Convert.ToInt32(ds.Tables[0].Rows[0][0]);
            Createddate = ds.Tables[0].Rows[0][1].ToString();
            id = Convert.ToInt32(ds.Tables[0].Rows[0][2]);
            return 1;
        }
        


    }
}