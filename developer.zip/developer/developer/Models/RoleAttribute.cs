﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Utilities;
using System.Configuration;
using System.Data;

namespace developer.Models
{
    public class RoleAttribute
    {
    }

    public class RoleFilterAttribute : ActionFilterAttribute
    {
        public string RoleName { set; get; }
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            DataSet ds= SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "IsUserOnRole", HttpContext.Current.User.Identity.Name, RoleName);
            if (Convert.ToInt32(ds.Tables[0].Rows[0]["IsUserOnRole"]) != 1)
            {
                throw new HttpException(403, "you don't have permissions to access this page");
            }
            filterContext.HttpContext.Trace.Write("(Logging Filter)Action Executing: " +
            filterContext.ActionDescriptor.ActionName);
            base.OnActionExecuting(filterContext);
        }
        public override void OnActionExecuted(ActionExecutedContext filterContext)
        {
            if (filterContext.Exception != null)
                filterContext.HttpContext.Trace.Write("(Logging Filter)Exception thrown");
            base.OnActionExecuted(filterContext);
        }
    } 
}