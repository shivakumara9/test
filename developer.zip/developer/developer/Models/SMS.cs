﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Net;
using System.IO;
using System.Net.Cache;

namespace developer.Models
{
    public class SMS
    {
        public string userName { set; get; }
        public string passWord { set; get; }
        
        private string url { set; get; }
        private HttpWebRequest req { set; get; }
        private HttpWebResponse response { set; get; }
        private CookieContainer cookieCntr { set; get; }
        private static string responseee { set; get; }
        private string WorkingSite { set; get; }
        public string siteUrl { set;get; }
        public string PhoneNo { set; get; }
        public SMS()
        {
            WorkingSite="site5";
            siteUrl=string.Format("http://{0}.way2sms.com", this.WorkingSite);
            List<Lookup> lk = new Lookup().GetLookupOnType("SMS");
            userName = lk.Single(m => m.LookupKey == "W2SUid").LookupText;
            passWord = lk.Single(m => m.LookupKey == "W2Spwd").LookupText;
            PhoneNo = lk.Single(m => m.LookupKey == "W2Sphone").LookupText;
        }
        bool Connect()
        {
            try
            {
                url = string.Empty;
                this.req = (HttpWebRequest)WebRequest.Create(string.Format("{0}/Login1.action", siteUrl));
                this.req = SetHeaders(this.req, false, string.Format("{0}/content/index.html", siteUrl), true);

                url = string.Format("username={0}&password={1}&userLogin=yes", userName, passWord);
                this.req.ContentLength = url.Length;
                StreamWriter writer = new StreamWriter(this.req.GetRequestStream(), System.Text.Encoding.ASCII);
                writer.Write(url);
                writer.Close();
                this.response = (HttpWebResponse)this.req.GetResponse();
                this.cookieCntr = this.req.CookieContainer;
                this.response.Close();

                string tmpUrl = this.req.RequestUri.AbsoluteUri;
                tmpUrl = string.Format("{0}/Main.action?id={1}", siteUrl, cookieCntr.GetCookies(req.RequestUri)[0].Value);
                this.req = (HttpWebRequest)WebRequest.Create(string.Format("{0}/jsp/InstantSMS.jsp", siteUrl));
                this.req = SetHeaders(this.req, false, tmpUrl, false);
                this.req.Method = "GET";
                this.req.CookieContainer = this.cookieCntr;

                this.response = (HttpWebResponse)this.req.GetResponse();
                responseee = new StreamReader(this.response.GetResponseStream()).ReadToEnd();

                string str = "<input type=\"hidden\" name=\"Action\" id=\"Action\"";
                int index = responseee.IndexOf(str, StringComparison.OrdinalIgnoreCase);
                string sub = responseee.Substring(index, 70);
                sub = sub.Split('>')[0];
                responseee = sub.Split(new string[] { "value=" }, StringSplitOptions.RemoveEmptyEntries)[1].Replace("\"", "").Trim();

                this.response.Close();
                
                return true;

            }
            catch (Exception ex) { return false; }
        }

        HttpWebRequest SetHeaders(HttpWebRequest reqest, bool useEncoding, string referer, bool isNewCookie)
        {
            reqest.Method = "POST";
            reqest.KeepAlive = true;
            HttpRequestCachePolicy cachePolicy = new HttpRequestCachePolicy(HttpRequestCacheLevel.Refresh);
            reqest.CachePolicy = cachePolicy;
            reqest.Headers.Add("Origin", siteUrl);
            reqest.UserAgent = "Mozilla/5.0 (Windows NT 6.2; WOW64) AppleWebKit/537.4 (KHTML, like Gecko) Chrome/22.0.1229.79 Safari/537.4";
            reqest.ContentType = "application/x-www-form-urlencoded";
            reqest.Accept = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8";
            if (!string.IsNullOrEmpty(referer))
                reqest.Referer = referer;
            if (useEncoding)
                reqest.Headers.Add("Accept-Encoding", "gzip,deflate,sdch");
            reqest.Headers.Add("Accept-Language", "en-US,en;q=0.8");
            reqest.Headers.Add("Accept-Charset", "ISO-8859-1,utf-8;q=0.7,*;q=0.3");
            reqest.AllowAutoRedirect = true;
            if (isNewCookie)
                reqest.CookieContainer = new CookieContainer();
            else
                reqest.CookieContainer = this.cookieCntr;
            return reqest;
        }

        bool SendMessage(string mobileNo, string Message)
        {
            try
            {
                this.req = (HttpWebRequest)WebRequest.Create(string.Format("{0}/quicksms.action", siteUrl));
                this.req = SetHeaders(this.req, false, string.Format("{0}/jsp/InstantSMS.jsp", siteUrl), false);
                this.url = string.Format("HiddenAction=instantsms&catnamedis=Birthday&Action={0}&chkall=on&MobNo={1}&textArea={2}", responseee, mobileNo, HttpContext.Current .Server.UrlEncode(Message));

                this.req.ContentLength = this.url.Length;
                StreamWriter writer = new StreamWriter(this.req.GetRequestStream(), System.Text.Encoding.ASCII);
                writer.Write(this.url);
                writer.Close();

                this.response = (HttpWebResponse)this.req.GetResponse();
                string ss = new StreamReader(this.response.GetResponseStream()).ReadToEnd();
                this.response.Close();
                return true;
            }
            catch { return false; }
        }

        public void SendSMS(string Msg)
        {
            if (Connect() == true)
            {
                string[] lst = PhoneNo.Split(',');
                foreach (string line in lst)
                {
                    SendMessage(line, Msg);
                }
            }
        }
    }
}