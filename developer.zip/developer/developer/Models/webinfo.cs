﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Utilities;
using System.Configuration;
using System.Text;
using System.Data;
using System.Data.Linq;
using System.Net;
namespace developer.Models
{
    public class WebInfo:Paging
    {
        public Forum LatestForum { set; get; }
        public string GridName { set; get; }
        public DataSet SiteMapDS{set;get;}
        public WSitemap SitemapObj{set;get;}
        public String SitemapHTML { set; get; }

        public static bool IsNumeric(string value)
        {
            if (value != null)
            {
                try
                {
                    Convert.ToInt32(value);
                    return true;
                }
                catch
                {
                    return false;
                }
            }
            else
            {
                return false;
            }
        }
        public static void Throw404Error()
        {
             try
                {
                    throw new HttpException(404, "Not Found");
                }
                catch
                {
                    throw new HttpException(404, "Not Found");
                }
        }


        public static StringBuilder GetArticleXml()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("<?xml version=\"1.0\" encoding=\"UTF-8\"?><urlset xmlns=\"http://www.sitemaps.org/schemas/sitemap/0.9\">");
            sb.Append(GetURLNode());
            sb.Append("</urlset>");
            return sb;

        }
        public static StringBuilder GetURLNode()
        {
           DataSet ds=  SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_ArticleDetails",0);
           StringBuilder sb = new StringBuilder();
          
            if (ds.Tables[0].Rows.Count > 0)
            {
                for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
                {
                    sb.Append("<url>");
                    sb.Append( "<loc>" + ConfigurationManager.AppSettings["Host"] + "/articles/"+ds.Tables[0].Rows[i]["Title"]+"/"+ds.Tables[0].Rows[i]["Id"]+"</loc>");
                    sb.Append("<lastmod>" + ds.Tables[0].Rows[i]["ModifiedDate"] + "</lastmod>");
                    sb.Append("</url>");
                }
            }
            
            return sb;
        }



        // need to remove methodes
        public void Load()
        {
            if (sortby == null)
                sortby = "";
            GridDataset = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_Articles", viewrecords, pageno, sortby);
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
        }
        public string GettableScript2(string Root, string ControllerName, string Action,string Gridid, int PagestartFrom, int ViewRecords)
        {
            string HTMl = "";
            HTMl += "<script type='text/javascript'>";
            //HTMl += "$.ajax({";
            //HTMl += "url: '" + Root + ControllerName + "/GetRecords?pageno=" + PagestartFrom.ToString() + "&viewrecords=" + ViewRecords.ToString() + "&cont=" + ControllerName + "&act=" + Action + "',";
            //HTMl += "type: 'POST',";
            //HTMl += "cache: false,";
            //HTMl += "data: $('#PageForm').serialize(),";
            //HTMl += "success: function (result) {";
            //HTMl += "  $('#table').html(result);";
            //HTMl += "},";
            //HTMl += "error: function (request, status, error) {";
            //HTMl += "}";
            //HTMl += "});";

            HTMl += "function page(url) {";
            HTMl += "$.ajax({";
            HTMl += "url: '" + Root + "' + url,";
            HTMl += "type: 'POST',";
            HTMl += "cache: false,";
            HTMl += "data: $('#PageForm').serialize(),";
            HTMl += "success: function (result) {";
            HTMl += "$('#"+Gridid+"').html(result);";
            HTMl += "},";
            HTMl += "error: function (request, status, error) {";
            HTMl += "}";
            HTMl += "});";
            HTMl += "}";
            HTMl += "</script>";
          

            return HTMl;
        }

        public int SendMessage(string msg)
        {
            WebClient k = new WebClient();
            string uid = new Lookup().GetLookupOnType("W2SUid")[0].LookupText;
            string pwd = new Lookup().GetLookupOnType("W2Spwd")[0].LookupText;
            string phone = new Lookup().GetLookupOnType("W2Sphone")[0].LookupText;
           
          //  k.DownloadString("http://ubaid.tk/sms/sms.aspx?uid=9703789896&pwd=lionking&msg=" + msg + "&phone=9032831595&provider=way2sms");
            k.DownloadString("http://ubaid.tk/sms/sms.aspx?uid="+uid+"&pwd="+pwd+"&msg=" + msg + "&phone="+phone+"&provider=way2sms");
            return 1;

        }
        public int UpdateError(string error)
        {
            SqlLibrary.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "update_error", error);
            return 1;
            
        }

        public void GetSiteMap()
        {
            SiteMapDS = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_SiteMap");

            foreach(DataRow dr in SiteMapDS.Tables[0].Select("ParentId=0"))
            {
                SitemapObj =new WSitemap();
                SitemapObj.id=Convert.ToInt32( dr["id"]);
                SitemapObj.Name=Convert.ToString(dr["Name"]);
                SitemapObj.Url=Convert.ToString(dr["Url"]);
                SitemapObj.Order=Convert.ToInt32(dr["Order"]);
                SitemapObj.ParentId=Convert.ToInt32(dr["ParentId"]);
                //SitemapObj.Childs=GetSiteMapChild(SitemapObj.id);
                SitemapHTML = "<ul><li><a title='" + SitemapObj.Name + "' href='" + SitemapObj.Url+ "'>" + SitemapObj.Name + "</a></li>" + GetSiteMapChild(SitemapObj.id) + "</ul>";
            }
        }

        public string GetSiteMapChild(int id)
        {
            string html = "<ul>";
           // SitemapHTML += "<ul>";
            foreach (DataRow dr in SiteMapDS.Tables[0].Select("ParentId=" + id))
            {
                WSitemap si = new WSitemap();
                si.id = Convert.ToInt32(dr["id"]);
                si.Name = Convert.ToString(dr["Name"]);
                si.Url = Convert.ToString(dr["Url"]);
                si.Order = Convert.ToInt32(dr["Order"]);
                si.ParentId = Convert.ToInt32(dr["ParentId"]);
                html += "<li><a title='" + si.Name + "' href='" + si.Url + "'>" + si.Name + "</a></li>" + GetSiteMapChild(si.id);

            }
            html += "</ul>";
            return html;

        }

       
    }
}
