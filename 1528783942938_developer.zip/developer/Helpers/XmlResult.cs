﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Text;
using System.IO;
using System.Xml.Serialization;
namespace developer.Helpers
{
    public class XmlResult:ActionResult
    {
        public StringBuilder Xml { get; set; }

        public override void ExecuteResult(ControllerContext context)
        {
            HttpContextBase httpcontextbase = context.HttpContext;
            httpcontextbase.Response.Buffer = false;
            httpcontextbase.Response.Clear();
         //  httpcontextbase.Response.AddHeader("content-disposition", "attachment; filename=xmlresult.xml");
            httpcontextbase.Response.ContentType = "text/xml";

            //using (StringWriter writer = new StringWriter())
            //{
            //    XmlSerializer xml = new XmlSerializer(typeof(String));
            //    xml.Serialize(writer, Xml);
            httpcontextbase.Response.Write(Xml);
           // }

        }
    }
}