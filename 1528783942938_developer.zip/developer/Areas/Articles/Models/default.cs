﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace developer.Areas.Articles.Models
{
    public class Default
    {

        public int ArticleId { set; get; }

    }
}
