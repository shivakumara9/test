﻿using System.Web.Mvc;

namespace developer.Areas.Articles
{
    public class ArticlesAreaRegistration : AreaRegistration
    {
        public override string AreaName
        {
            get
            {
                return "Articles";
            }
        }

        public override void RegisterArea(AreaRegistrationContext context)
        {
            context.MapRoute(
                "Articles_default",
                "Articles/{name}/{id}",
                new { controller = "default", action = "Index",  name = UrlParameter.Optional, id = UrlParameter.Optional } // Parameter defaults
            );
        }
    }
}
