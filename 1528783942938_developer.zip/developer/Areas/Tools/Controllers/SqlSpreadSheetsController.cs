﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using System.IO;
using System.Data.OleDb;
using System.Data;
using Aspose.Cells;
using System.Collections;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.UI.WebControls;
using System.Web.UI;
namespace developer.Areas.Tools.Controllers
{
    public class SqlSpreadSheetsController : Controller
    {
        //
        // GET: /Tools/SpreadSheets/

        [HttpGet]
        public ActionResult Index()
        {
            Spreadsheets model = new Spreadsheets();
            model.SetSheets();
            model.SQL = String.IsNullOrEmpty(model.SQL) ? "Syntax:\n\nSelect *\nFrom\nFile-name.Sheet-name" : model.SQL;
            return View(model);
        }
        [HttpPost]
        public ActionResult Index(Spreadsheets model)
        {
            ModelState.Clear();
            string Random="";
            int Err = 0;
            int success=0;
            string msg = "";
            string [] Files;
           // Spreadsheets model = new Spreadsheets();
            if (Request.Files.Count > 0)
            {
                if (Session["SheetsPath"] == null)
                {
                    //  Session.Timeout = 1;
                    Random m = new Random();
                    Session["SheetsPath"] = Random = m.Next().ToString();

                }
                else
                {
                    Random = Session["SheetsPath"].ToString();
                }

                for (int i = 0; i < Request.Files.Count; i++)
                {

                    if (Request.Files[i].FileName.ToLower().Contains(".xls") || Request.Files[i].FileName.ToLower().Contains(".xlsx"))
                    {
                        Workbook wb = new Workbook(Request.Files[i].InputStream);
                        
                        for (int j = 0; j < wb.Worksheets.Count; j++)
                        {
                            if (wb.Worksheets[j].Cells.MaxDataRow > -1 || wb.Worksheets[j].Cells.MaxDataColumn > -1)
                            {
                                DataTable da = wb.Worksheets[j].Cells.ExportDataTable(0, 0, wb.Worksheets[j].Cells.MaxDataRow + 1, wb.Worksheets[j].Cells.MaxDataColumn + 1);
                                model.MakeTable(Random, wb.Worksheets[j].Name.Replace(" ", "_"), j, da);
                                if (!string.IsNullOrEmpty(model.Err))
                                {                                   
                                    Err = 1;
                                }
                                else
                                {
                                    success = 1;
                                }

                            }
                        }
                        if (success == 1 && Err == 1)
                        {
                            model.Msg = "Some of your sheets are not valid, may be problem with special chars or empty columns";
                        }
                        else if (Err == 1)
                        {
                            ModelState.AddModelError("", model.Err);
                        }
                    }
                    else
                    {
                        ModelState.AddModelError("", "Please upload a spread sheet.");

                    }
                    i++;
                }

            }
            else
            {
                ModelState.AddModelError("", "Please upload a spread sheet.");
            }

            model.RandomNum = Random;
            model.SetSheets();
            model.SQL = String.IsNullOrEmpty(model.SQL) ? "Syntax:\n\nSelect *\nFrom\nFile-name.Sheet-name" : model.SQL;
            return View(model);
        }

        [HttpPost]
        public ActionResult Download(Spreadsheets model)
        {
            model.FormateSQL();
            model.GetResultSQL();

            return File(ExportDataTableToExcel(model.Result), "application/vnd.ms-excel", "results.xls");
           // return null;
        }

        public ActionResult Execute(Spreadsheets model)
        {
            string Err=model.ValidateSql();
            if (Err != "")
                ModelState.AddModelError("SQL", Err);
            if (ModelState.IsValid)
            {
                model.FormateSQL();
                Err = model.GetResultSQL();
                if (Err != "")
                    ModelState.AddModelError("SQL", Err);
            }
            
            model.SetSheets();
            model.SQL = String.IsNullOrEmpty(model.SQL) ? "Syntax:\n\nSelect *\nFrom\nFile-name.Sheet-name" : model.SQL;
            return View("Index", model);
        }

        public byte[] ExportDataTableToExcel(DataSet dt)
        {
            ExcelUtil.Excel e = new ExcelUtil.Excel();
            byte[] k = e.GetExcelonDataset(dt);
            return k;
        }




    }
}
