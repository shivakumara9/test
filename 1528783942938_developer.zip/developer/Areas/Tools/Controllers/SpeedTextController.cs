﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using System.Text.RegularExpressions;

namespace developer.Areas.Tools.Controllers
{
    public class SpeedTextController : Controller
    {
        //
        // GET: /Tools/SpeedText/

        [HttpGet]
        public ActionResult Index()
        {
            SpeedText model = new SpeedText();
            return View(model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Index(SpeedText model,Dictionary<string, string[]> Hvalues)
        {
            ModelState.Clear();
            try
            {
                model.Hvalues = Hvalues;
                model.Placeholders();
                model.GetResult();
            }
            catch
            {
                ModelState.AddModelError("Result", "Opps... your template has errors");
            }
            return View(model);
        }

        [ValidateInput(false)]
        public ActionResult Repeat(SpeedText model)
        {
            try
            {
                ModelState.Clear();
                if (model.MainText != null && model.Endtext != 0 && model.Endtext - model.Starttext > 0)
                {
                    model.MainText = model.MainText.Replace("\r\n", "\n");
                    model.MainText = model.MainText.Insert(model.Endtext, "{{" + model.NoofRepeats + "##}}");
                    model.MainText = model.MainText.Insert(model.Starttext, "{{##" + model.NoofRepeats + "}}");
                    model.RepeatBit = 1;
                }
            }
            catch
            {
                ModelState.AddModelError("", "Opps... Erros in your selection");
            }
            return View("Index", model);
        }

        [ValidateInput(false)]
        public ActionResult PlaceHolders(Dictionary<string, string[]> Hvalues, string Harr, SpeedText model)
        {
            try
            {
                ModelState.Clear();
                model.Hvalues = Hvalues != null ? Hvalues : new Dictionary<string, string[]>();
                //model.Hvaluesarr = !string.IsNullOrEmpty(Harr) ? Harr.Split(',') : new string[] { };
                model.Placeholders();
            }
            catch
            {
                ModelState.AddModelError("", "Opps... your template has errors");
            }
            return View("PlaceHolders", model);
        }

        [Authorize()]
       // [HttpPost]
        [ValidateInput(false)]
        public ActionResult Save(SpeedText model, Dictionary<string, string[]> Hvalues)
        {
            try
            {
                model.Hvalues = Hvalues;
                model.Placeholders();
                model.save();
            }
            catch
            {
                ModelState.AddModelError("Result", "Opps... your template has errors");
            }
            return View("Index",model);
        }

        [HttpPost]
        [ValidateInput(false)]
        public ActionResult Templates(SpeedText model, Dictionary<string, string[]> Hvalues)
        {
            model.pageno = model.pageno == 0 ? 1 : model.pageno;
            model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
            model.TemplateBit = 1;
            model.Hvalues = Hvalues;
            model.Placeholders();
            model.SetTemplateGrid("");
            model.ispagepost = false;
            //model.url="~/Tools/SpeedText/Templates";
          //  model.formid = "SpeedTextFrm";
            model.GridId = "NTemplatesGrid";
            ViewData["Tname"] = "Templates";
            return View("Templates", model);
        }

        [HttpPost]
        [ValidateInput(false)]
        [Authorize()]
        public ActionResult MyTemplates(SpeedText model, Dictionary<string, string[]> Hvalues)
        {
            model.pageno = model.pageno == 0 ? 1 : model.pageno;
            model.viewrecords = model.viewrecords == 0 ? 10 : model.viewrecords;
            model.TemplateBit = 1;
            model.Hvalues = Hvalues;
            model.Placeholders();
            model.SetTemplateGrid(HttpContext.User.Identity.Name);
            ViewData["Tname"] = "My Templates";
            return View("Templates", model);
        }
        

      //  [HttpPost]
        [ValidateInput(false)]
        public ActionResult Open(SpeedText model, Dictionary<string, string[]> Hvalues)
        {
            ModelState.Clear();
            try
            {
                model.Hvalues = Hvalues;
                model.Placeholders();
                model.GetTemplate();
            }
            catch
            {
                ModelState.AddModelError("Result", "Opps... your template has errors");
            }
            return View("Index",model);
        }
    }
}
