﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
namespace developer.Controllers
{
    public class ArticlesController : Controller
    {
        //
        // GET: /Articles/

        public ActionResult Index(string category)
        {
            WebInfo model = new WebInfo();
            return View("Articles", model);
        }

        public ActionResult kk(string category)
        {
            WebInfo model = new WebInfo();
            return View("Articles", model);
        }

     

    }
}
