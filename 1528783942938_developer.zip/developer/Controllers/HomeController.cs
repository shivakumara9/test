﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using ShivaKumarDAL;
using developer.Helpers;
using System.Text;
using System.Drawing;
namespace developer.Controllers
{
    [HandleError]
    public class HomeController:pagingController
    {
        public ActionResult Index(WebInfo model)
        {
            
                model.pageno = model.pageno == 0 ? 1 : model.pageno;
                model.viewrecords = model.viewrecords == 0 ? 5 : model.viewrecords;
                model.Load();
                model.ispagepost = true;
                model.formid = "Gridform";
                model.GridId = "Gridform";            
                if (model.LatestForum == null)
                    model.LatestForum = new developer.Models.Forum();
                model.LatestForum.pageno = model.LatestForum.pageno == 0 ? 1 : model.LatestForum.pageno;
                model.LatestForum.viewrecords = model.LatestForum.viewrecords == 0 ? 5 : model.LatestForum.viewrecords;
                model.LatestForum.LoadCatGrid();
               // model.LatestForum.url = "Home/Latestforums";
                model.LatestForum.ispagepost = true;
                model.LatestForum.formid = "ForumsGridform";
                model.LatestForum.GridId = "ForumsGridform";
                model.LatestForum.QSConcatinate = "LatestForum";
            
            return View(model);
        }
        public ActionResult Latestforums(WebInfo model)
        {
            int fourmpageno = model.pageno;
            model.pageno = model.LatestForum.pageno == 0 ? 1 : model.LatestForum.pageno;
            model.viewrecords = model.viewrecords == 0 ? 5 : model.viewrecords;
            model.Load();
            model.ispagepost = true;
            model.formid = "Gridform";

            if (model.LatestForum == null)
                model.LatestForum = new developer.Models.Forum();
            model.LatestForum.pageno = fourmpageno == 0 ? 1 : fourmpageno;
            model.LatestForum.viewrecords = model.LatestForum.viewrecords == 0 ? 5 : model.LatestForum.viewrecords;
            model.LatestForum.LoadCatGrid();
            model.LatestForum.url = "Home/Latestforums";
            model.LatestForum.ispagepost = true;
            model.LatestForum.formid = "ForumsGridform";
            model.LatestForum.QSConcatinate = "LatestForum";
            return View("Index", model);
        }

        public ActionResult About()
        {
            return View();
        }

        public ActionResult GetSubcategories(string CType, int categoryid)
        {
            return Json(new Lookup().GetLookupOnTypeNRel(CType, categoryid));
        }

        public ActionResult GetTableHtml(WebInfo model)
        {
            model.Load();
            return View("table", model);
        }


        public ActionResult Sitemap()
        {
            WebInfo wi = new WebInfo();
            wi.GetSiteMap();
            return View(wi);
        }
        public ActionResult Vad()
        {
            return View();
        }
        public ActionResult ProfileImage(string UserName)
        {
            developer.Models.User model = new Models.User();
            model.UserName = UserName;
            model.GetImage();
            if (model.Image == null)
                return null;
            else
                return File(model.Image, "image/jpeg");

        }

        public ActionResult LatestUpdates()
        {
            return View();
        }

        public ActionResult Faq()
        {
            Faq model = new Faq();
            return View(model);
        }

        public ActionResult Contactus()
        {
            ContactUs model=new ContactUs();
            Random k = new Random();
            Session["contactus"] = k.Next(10000, 100000);
            return View(model);
        }

        [HttpPost]
        public ActionResult Contactus(ContactUs model)
        {
            if (Convert.ToString(Session["contactus"]) != model.captcha)
                ModelState.AddModelError("captcha", "Entered characters as shown in the above picture is not correct");
            if (ModelState.IsValid)
            {
                model.SendMail();
                ViewData["mail"] = new string[] { "Your request has been submited", "success" };
            }
            return View(model);
        }

        public ActionResult Captcha(string id)
        {
            if (Session[id] == null)
            {
                Random k = new Random();
                Session[id] = k.Next(10000, 100000);
            }
            return File((byte[])new ImageConverter().ConvertTo(new CaptchaImage(Session[id].ToString(), 200, 50).Image, typeof(byte[])), "img/jpg");
        }

        public ActionResult Articles(Article model)
        {
            model.LoadCatGrid();
            return View("Latestupdates", model);
        }

        public ActionResult Privacypolicy()
        {
            return View();
        }

        public ActionResult TermsofUse()
        {
            return View();
        }

        public ActionResult Aboutus()
        {
            return View();
        }
        
        
    }
}
