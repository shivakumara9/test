﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using developer.Models;
using System.Web.Security;
using System.Drawing;
namespace developer.Controllers
{
    public class AcountController : DevController
    {
        //
        // GET: /Acount/

        public ActionResult Index()
        {
            Acount model = new Acount();
            Random k = new Random();
            Session["random"] = k.Next(10000, 100000);
            return View("Register", model);
        }

        [HttpPost]
        public ActionResult Index(Acount model)
        {
            if (model.IsUserAvailable() == 1)
            {
                ModelState.AddModelError("UserName", "Someone already has that username. Try another?");
            }
            if (model.Password != model.ConfirmPassword)
            {
                ModelState.AddModelError("ConfirmPassword", "Password and Confirm password must match");
            }
            string captcha=Session["random"]==null?"":Session["random"].ToString();
            if (captcha != model.Captcha)
            {
                ModelState.AddModelError("Captcha", "Characters  you entered from picture are not correct");
            }
            if (ModelState.IsValid)
            {
                model.EmailConfirmCode = new Random().Next(10000, 100000).ToString();
                model.Update();
                model.SendEmail();
                model.SendMessage();
                return View("AfterRegister", model);
            }
            else
            {
                return View("Register", model);
            }
            
        }


        public ActionResult Login()

        {
            Acount model = new Acount();
            string k = Crypto.Encrypt("dotnetreaders", "9dotnetreaders9");
            return View("Login", model);
        }

        [HttpPost]
        public ActionResult Login(Acount model)
        {
            if (model.validate() == 1)
            {
                FormsAuthentication.SetAuthCookie(model.UserName, false);

                string url = HttpContext.Request.QueryString["RedirectUrl"];
                ScrollTo = HttpContext.Request.QueryString["ScrTo"];
                ScrollTo = string.IsNullOrEmpty(ScrollTo) == true ? "" : "#" + ScrollTo;
                if (!string.IsNullOrEmpty(url))
                    Response.Redirect("~/" + url + ScrollTo);
                return RedirectToAction("Index", "member");
            }
            else
            {
                ViewData["userErr"] = 1;
                return View("Login", model);
            }

        }
        public ActionResult LogOut()
        {
            FormsAuthentication.SignOut();
            if (string.IsNullOrEmpty(User.Identity.Name))
            {
                return View("Login", new Acount());
            }
            else
            {
                FormsAuthentication.SignOut();
                return View("Login", new Acount());
            }
           
        }
        public ActionResult Captcha()
        {
            if (Session["random"] == null)
            {
                Random k = new Random();
                Session["random"] = k.Next(10000, 100000);
            }
            return File((byte[])new ImageConverter().ConvertTo(new CaptchaImage(Session["random"].ToString(), 200, 50).Image, typeof(byte[])), "img/jpg");
        }

        public int UserNameAvalible(Acount model)
        {
            return  model.IsUserAvailable();
        }
        public ActionResult verify(string email, string code)
        {
            Acount model = new Acount();
            model.Email = email;
            model.EmailConfirmCode = code;
            ViewData["EmailConfirm"] = model.VerifyEmail();
            model.Sendverificationmessage();
            return View(model);
        }

        public ActionResult forgotpassword()
        {
            Acount model = new Acount();
            Random k = new Random();
            Session["forgot"] = k.Next(10000, 100000);
            return View(model);
        }

        [HttpPost]
        public ActionResult forgotpassword(Acount model)
        {
            ModelState.Remove("Gender");
            ModelState.Remove("UserName");
            ModelState.Remove("Password");
            ModelState.Remove("ConfirmPassword");
            

            if (Convert.ToString(Session["forgot"]) != model.Captcha)
                ModelState.AddModelError("captcha", "Entered characters as shown in the above picture is not correct");
            if (ModelState.IsValid)
            {
                if (model.forgotmypassword() == 1)
                    ViewData["mail"] = new string[] {"Your password details has been sent to you email.","success"};
                else
                    ViewData["mail"] = new string[] { "Entered email is not found in our records.", "error" };
            }
            

            return View(model);
        }
    }
}
