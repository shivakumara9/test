﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ShivaKumarDAL;
using System.Configuration;
using System.Data;
using System.Collections;
using ShivaKumar;
using System.IO;

namespace developer.Models
{
    public class User:Paging
    {
        
        public string UserName { set; get; }
        public string FullName { set; get; }
        public int Credits { set; get; }
        public string SubmitedDate { set; get; }
        public byte[] Image { get; set; }
        public string Level { set; get; }
        public string LevelKey { set; get; }
        public DataTable LatestUpdatesDt{ set; get; }
        public TabSettings UserTabs { set; get; }
        public Article UserArticles { set; get; }
        public Forum UserForum { set; get; }
        public int PostedArticles { set; get; }
        public int PostedForums { set; get; }
        public int PostedForumAnswers { set; get; }
        public string LastLoggedinDate { set; get; }
        public string Gender { set; get; }


        public User()
        {
            UserArticles = new Article();
            UserForum = new Forum();
        }

        
        public int GetUserDetails()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_Member_details",  UserName);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Gender = Convert.ToString(ds.Tables[0].Rows[0]["gender"]);
                FullName = ds.Tables[0].Rows[0]["Name"].ToString();
                Credits = Convert.ToInt32(ds.Tables[0].Rows[0]["TotalCredits"]);
                SubmitedDate = ds.Tables[0].Rows[0]["joineddate"].ToString();
                Level = ds.Tables[0].Rows[0]["Level"].ToString();
                LevelKey = ds.Tables[0].Rows[0]["LevelKey"].ToString();
                PostedArticles = Convert.ToInt32(ds.Tables[0].Rows[0]["ArticlesPosted"]);
                PostedForums = Convert.ToInt32(ds.Tables[0].Rows[0]["ForumPosted"]);
                PostedForumAnswers = Convert.ToInt32(ds.Tables[0].Rows[0]["ForumAnswersPosted"]);

                return 1;
            }
            else
                return 0;




        }

        public int GetUserLatestUpdates()
        {
            if (sortby == null)
                sortby = "v.id";
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_User_LatestUpdates",viewrecords,pageno,sortby, UserName);
            GridDataset = ds;
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
            return 1;
        }

        public void GetImage()
        {
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_imageofuser", UserName);
            if (ds.Tables[0].Rows.Count > 0)
            {
                Image = (byte[])ds.Tables[0].Rows[0]["image"];
            }
            
            
        }

        

        public List<User> UsersList()
        {
            List<User> UserList = new List<User>();
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_User_PostsCount");
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                User m = new User() { UserName = Convert.ToString(dr["username"]), FullName = Convert.ToString(dr["fname"]), PostedArticles = Convert.ToInt32(dr["articles"]), PostedForumAnswers = Convert.ToInt32(dr["fourm_response"]), PostedForums = Convert.ToInt32(dr["forums"]), Gender = Convert.ToString(dr["gender"]) };
                UserList.Add(m);
            }
            return UserList;
        }
        
    }
}