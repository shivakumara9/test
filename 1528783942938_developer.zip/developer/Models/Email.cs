using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;
using System.Data.SqlClient;
/// <summary>
/// Returns "ok" if mail is sent
/// </summary>
/// 
namespace developer.Models
{
    public class Email
    {

        /// <summary>
        /// Returns "ok" if mail is sent
        /// </summary>
        public static string SendEmail(string from, string fromDisplay, string to, string sender,
            string replyTo, string subject, string body, System.Text.Encoding subjectEncoding,
            System.Text.Encoding bodyEncoding, bool isBodyHtml, string smtpHost, string smtpUser,
            string smtpPass, int smtpPort, string smtpAuthType)
        {
            string response = null;
            System.Net.Mail.MailAddress maFrom = new System.Net.Mail.MailAddress(from, fromDisplay);
            System.Net.Mail.MailAddress maTo = new System.Net.Mail.MailAddress(to);
            System.Net.Mail.MailAddress maSender = new System.Net.Mail.MailAddress(sender);
            // System.Net.Mail.MailAddress maReplyTo = new System.Net.Mail.MailAddress(replyTo);
            System.Net.Mail.MailMessage msg = new System.Net.Mail.MailMessage(maFrom, maTo);
            msg.Body = body;
            msg.Sender = maSender;
            // msg.ReplyTo = maReplyTo;
            msg.Subject = subject;
            msg.BodyEncoding = bodyEncoding;
            msg.IsBodyHtml = isBodyHtml;
            msg.SubjectEncoding = subjectEncoding;

            System.Net.Mail.SmtpClient smtp = new System.Net.Mail.SmtpClient(smtpHost);
            System.Net.NetworkCredential nc = new System.Net.NetworkCredential(smtpUser, smtpPass);
            smtp.Credentials = (System.Net.ICredentialsByHost)nc.GetCredential(smtpHost, smtpPort, smtpAuthType);

            try
            {
                smtp.Send(msg);
                return "ok";
            }
            catch (Exception ex)
            {
                response = ex.Message;
                response = response.Replace("\r\n", "<br/>");
                return response;
            }
        }


        public static void SendEmailForFourm(string touser, string url, string questionname)
        {

            string toemail = "";

            SqlConnection cn = new SqlConnection(System.Web.Configuration.WebConfigurationManager.ConnectionStrings[2].ConnectionString);
            cn.Open();
            SqlDataAdapter da = new SqlDataAdapter("GetUserDetailsfromusername", cn);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.Add("@username", SqlDbType.VarChar).Value = touser;
            DataSet ds = new DataSet();
            da.Fill(ds);
            cn.Close();

            string html = " Dear " + ds.Tables[0].Rows[0]["uname"].ToString() + ",<br /><br />You have a response for your question  \"" + questionname + "\". To see the Response please click this below link<br /><a  target='_blank' href='" + url + "'>" + url + "</a> <br /> <br />  Regards,<br />  http://99web.info";
            string k = SendEmail("noreplay@99web.info", "99web.info", ds.Tables[0].Rows[0]["email"].ToString(), "support@astrotelugu.com", "info@99web.info", "Responce for your question", html, System.Text.Encoding.ASCII, System.Text.Encoding.UTF8, true, "mail.astrotelugu.com", "support@astrotelugu.com", "Srividya24", 25, "Basic");



        }


    }
}