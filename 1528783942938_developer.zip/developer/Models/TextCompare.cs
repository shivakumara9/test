﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace developer.Models
{
    public class TextCompare
    {
        public string LeftText { set; get; }
        public string RightText { set; get; }
        public string ComparedLeftText { set; get; }
        public string ComparedRightText { set; get; }
        public string Center { set; get; }
        public int Result { set; get; }

        public List<string> Compare(string left, string right)
        {
            string[] Larr = left.Split(new string[] { " " }, StringSplitOptions.None);
            string[] Rarr = right.Split(new string[] { " " }, StringSplitOptions.None);
            int count = Larr.Length > Rarr.Length ? Larr.Length : Rarr.Length;
            int Cless = Larr.Length > Rarr.Length ? Rarr.Length : Larr.Length;
            for (int i = 0; i < count; i++)
            {
                if (i < Cless)
                {
                    if (Larr[i] == Rarr[i])
                    {
                        Larr[i] = "<span style='color:green'>" + System.Web.HttpUtility.HtmlEncode(Larr[i]) + "</span>";
                        Rarr[i] = "<span style='color:green'>" + System.Web.HttpUtility.HtmlEncode(Rarr[i]) + "</span>";
                    }
                    else
                    {
                        List<string> li = CharCompare(Larr[i], Rarr[i]);
                        Larr[i] = li[0];
                        Rarr[i] = li[1];
                    }
                }
                else
                {
                    if (Larr.Length > Rarr.Length)
                    {
                        Larr[i] = "<span style='color:blue;background-color:#B8D0E8'>" + System.Web.HttpUtility.HtmlEncode(Larr[i]) + "</span>";
                    }
                    else if (Rarr.Length > Larr.Length)
                    {
                        Rarr[i] = "<span style='color:blue;background-color:#B8D0E8'>" +System.Web.HttpUtility.HtmlEncode( Rarr[i]) + "</span>";
                    }
                }
            }
          
            left = string.Join(" ", Larr);
            right = string.Join(" ", Rarr);
            Result = 1;
            List<string> k = new List<string>();
            k.Add(left);
            k.Add(right);
            return k;
        }
        public List<string> CharCompare(string left, string right)
        {
            string lst = "", rst = "";
            int count = left.Length > right.Length ? left.Length : right.Length;
            int Cless = left.Length > right.Length ? right.Length : left.Length;
            int g = 0, r = 0, b = 0;
            for (int i = 0; i < count; i++)
            {
                if (i < Cless)
                {
                    
                    if (left.Substring(i, 1) == right.Substring(i, 1))
                    {
                        if (r == 1)
                        {
                            lst += "</span>";
                            rst += "</span>";
                            r = 0;
                        }
                        lst += (g == 0 ? "<span style='color:green'>" : "") + System.Web.HttpUtility.HtmlEncode(left.Substring(i, 1));
                        rst += (g == 0 ? "<span style='color:green'>" : "") + System.Web.HttpUtility.HtmlEncode(right.Substring(i, 1));
                        g = 1;
                    }
                    else
                    {
                        if (g == 1)
                        {
                            lst += "</span>";
                            rst += "</span>";
                            g = 0;
                        }

                        lst += (r == 0 ? "<span style='color:red;background-color:#FFE5B4'>" : "") + System.Web.HttpUtility.HtmlEncode(left.Substring(i, 1));
                        rst += (r == 0 ? "<span style='color:red;background-color:#FFE5B4'>" : "") + System.Web.HttpUtility.HtmlEncode(right.Substring(i, 1));
                        r = 1;
                    }
                }
                else
                {
                    if (g == 1 || r == 1)
                    {
                        lst += "</span>";
                        rst += "</span>";
                        g = 0; r = 0;
                    }

                    if (left.Length > right.Length)
                    {
                        lst += "<span style='color:blue;background-color:#B8D0E8'>" + System.Web.HttpUtility.HtmlEncode(left.Substring(i,count-i)) + "</span>";
                    }
                    else if (right.Length > left.Length)
                    {
                        rst += "<span style='color:blue;background-color:#B8D0E8'>" + System.Web.HttpUtility.HtmlEncode(right.Substring(i,count-i)) + "</span>";
                    }
                    break;
                }
                
            }
            if (g == 1 || r == 1)
            {
                lst += "</span>";
                rst += "</span>";
                g = 0; r = 0;
            }

           
            
            List<string> k = new List<string>();
            k.Add(lst);
            k.Add(rst);
            return k;
        }

        public void Compare()
        {
            if (!string.IsNullOrEmpty(LeftText) && !string.IsNullOrEmpty(RightText))
            {
                string[] Larr = Convert.ToString(LeftText).Split(new string[] { "\r\n" }, StringSplitOptions.None);
                string[] Rarr = Convert.ToString(RightText).Split(new string[] { "\r\n" }, StringSplitOptions.None);
                int count = Larr.Length > Rarr.Length ? Larr.Length : Rarr.Length;
                int Cless = Larr.Length > Rarr.Length ? Rarr.Length : Larr.Length;
                for (int i = 0; i < count; i++)
                {
                    if (i < Cless)
                    {
                        List<string> li = CharCompare(Larr[i], Rarr[i]);
                        Larr[i] = li[0];
                        Rarr[i] = li[1];
                        Center += Larr[i].Contains("<span style='color:red;background-color:#FFE5B4'>") ? "<div style='color:red;background-color:#FFE5B4'>" + (i + 1) + "</div>" : Larr[i].Contains("<span style='color:blue;background-color:#B8D0E8'>") ? "<div style='color:blue;background-color:#B8D0E8;'>" + (i + 1) + "</div>" : "<div>" + (i + 1) + "</div>";
                    }
                    else
                    {

                        if (Larr.Length > Rarr.Length)
                        {
                            Larr[i] = "<span style='color:blue;background-color:#B8D0E8'>" + System.Web.HttpUtility.HtmlEncode(Larr[i]) + "</span>";
                        }
                        else if (Rarr.Length > Larr.Length)
                        {
                            Rarr[i] = "<span style='color:blue;background-color:#B8D0E8'>" + System.Web.HttpUtility.HtmlEncode(Rarr[i]) + "</span>";
                        }
                    }
                }

                ComparedLeftText = string.Join("<br/>", Larr);
                ComparedRightText = string.Join("<br/>", Rarr);
                Result = 1;
            }
        }
    }
}