﻿using System.Data;
using System.Data.Sql;
using System.IO;
using System.Xml;
using System.Xml.Xsl;
using System;
using NPOI.HSSF.UserModel;
using NPOI.SS.UserModel;
using NPOI.HPSF;


namespace ExcelUtil
{
    public class Excel
    {
       HSSFWorkbook hssfworkbook;
       public byte[] GetExcelonDataset(DataSet ds)
       {
           InitializeWorkbook();
           for (int t = 0; t < ds.Tables.Count;t++ )
           {
               DataTable dt = ds.Tables[t];
               ISheet sheet1 = hssfworkbook.CreateSheet("Sheet "+(t+1));
               for (int i = 0; i < dt.Rows.Count; i++)
               {
                   IRow row = sheet1.CreateRow(i);
                   for (int j = 0; j < dt.Rows[i].ItemArray.Length; j++)
                   {
                       row.CreateCell(j).SetCellValue(dt.Rows[i][j].ToString());
                   }
               }

           }
           return GetExcelStream().GetBuffer();
       }
       MemoryStream GetExcelStream()
        {
            //Write the stream data of workbook to the root directory
            MemoryStream file = new MemoryStream();
            hssfworkbook.Write(file);
            return file;
        }

      

       void InitializeWorkbook()
        {
            hssfworkbook = new HSSFWorkbook();

            ////create a entry of DocumentSummaryInformation
            DocumentSummaryInformation dsi = PropertySetFactory.CreateDocumentSummaryInformation();
            dsi.Company = "NPOI Team";
            hssfworkbook.DocumentSummaryInformation = dsi;

            ////create a entry of SummaryInformation
            SummaryInformation si = PropertySetFactory.CreateSummaryInformation();
            si.Subject = "NPOI SDK Example";
            hssfworkbook.SummaryInformation = si;
        }
    }
}

