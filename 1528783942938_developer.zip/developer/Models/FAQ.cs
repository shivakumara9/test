﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ShivaKumarDAL;
using System.Configuration;
using System.Data;
using System.Runtime.Serialization;
namespace developer.Models
{
    public class Faq
    {
        
        public int Id { set; get; }
        public string Question { set; get; }
        public string Answer { set; get; }

        public List<Faq> FaqList { set; get; }

      
        public Faq()
        {
            FaqList = new List<Faq>();
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_FaqList");
            foreach (DataRow dr in ds.Tables[0].Rows)
            {
                //MyClass myClass = (MyClass)FormatterServices.GetUninitializedObject(typeof(MyClass)); //does not call ctor

                Faq item = (Faq)FormatterServices.GetUninitializedObject(typeof(Faq));
                item.Id = Convert.ToInt32(dr["id"]);
                item.Question = dr["Question"].ToString();
                item.Answer = dr["Answer"].ToString();
                FaqList.Add(item);
            }
        }

    }
}