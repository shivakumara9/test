﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Globalization;
using System.Data.Linq;
using System.Net;
using System.Drawing;
namespace developer.Models
{
    public class StringLength
    {
        public string Stringval { set; get; }
        
        public int AvoidNewLines { set; get; }
        public int Result { set; get; }

        public string ReverseStringval { set; get; }

        public string UpperCase { set; get; }
        public string LowerCase { set; get; }
        public string ProperCase { set; get; }

        public int WordCountVal { set; get; }

        public string HtmlEncodedVal { set; get; }

        public string HtmlDecodedVal { set; get; }

        public string[] RGB { set; get; }
        public int Calc()
        {
            if (AvoidNewLines == 1)
            {
                Stringval = Convert.ToString(Stringval).Replace("\n\r", "");                
            }
            Result = Convert.ToString(Stringval).Length;
            return Result;
        }

        public void Reverse()
        {
            char[] arr = Stringval.ToCharArray();
            Array.Reverse(arr);
            ReverseStringval= new string(arr);
        }

        public void ConvertCase()
        {
            UpperCase = Stringval.ToUpper();
            LowerCase = Stringval.ToLower();
            
            CultureInfo properCase = System.Threading.Thread.CurrentThread.CurrentCulture;
            TextInfo currentInfo = properCase.TextInfo;
            ProperCase = currentInfo.ToTitleCase(currentInfo.ToLower(Stringval));
        }

        public void WordCount()
        {
           string [] arr= Stringval.Split(' ');
           List<string> k = arr.ToList();
           k.RemoveAll(str => String.IsNullOrEmpty(str));
           WordCountVal = k.Count;
        }

        public void HtmlEncode()
        {
            HtmlEncodedVal = WebUtility.HtmlEncode(Stringval);
            
        }

        public void Htmldecode()
        {
            HtmlDecodedVal = WebUtility.HtmlDecode(Stringval);

        }

        public void HextoRGB()
        {
            if (!Stringval.Contains("#"))
                Stringval = "#" + Stringval;
            ColorConverter cc = new ColorConverter();              
            Color color = (Color)cc.ConvertFromString(Stringval);
            RGB = new string[] { color.R.ToString(), color.G.ToString(), color.B.ToString()};
        }
    }
}