﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace developer.Models
{
    public class ContactUs
    {
        [Required(ErrorMessage = "Please enter User Name")]
        public string Name { set; get; }
        [Required(ErrorMessage = "Please enter From Email")]
        [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*", ErrorMessage = "Please enter valid From Email")]
        public string FromEmail { set; get; }
        [Required(ErrorMessage = "Please enter Subject")]
        public string Subject { set; get; }
        [Required(ErrorMessage = "Please enter Message")]
        public string Message { set; get; }
        [Required(ErrorMessage = "Please enter characters as shown in the above below")]
        public string captcha { set; get; }

        public int SendMail()
        {
            if (developer.Models.Email.SendEmail(FromEmail, Name,"9shivakumar9@gmail.com", FromEmail, "noreplay@devchips.com",Subject,Message, System.Text.Encoding.ASCII, System.Text.Encoding.UTF8, true, "mail.devchips.com", "noreplay@devchips.com", "kalikashiva9", 25, "Basic") == "ok")
            {

                return 1;
            }
            return 0;
        }
        
    }
}