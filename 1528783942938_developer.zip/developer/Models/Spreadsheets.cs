﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Collections;
using Aspose.Cells;
using System.Data.SqlClient;
using System.Data;
using System.Configuration;
using ShivaKumarDAL;
namespace developer.Models
{
    public class Spreadsheets
    {
        public DataSet Sheets { set; get; }
        public DataSet Result { set; get; }
        public string SheetTemptablename { set; get; }
        public string SQL { set; get; }
        public string RandomNum { set; get; }
        public System.IO.MemoryStream Memory { set; get; }
        public bool ColumnsinFirstRow { set; get; }
        public string Err { set; get; }
        public string Msg { set; get; }
        public Spreadsheets()
        {
            Sheets = new DataSet();
            if (HttpContext.Current.Session["SheetsPath"] != null)
            {
                RandomNum=HttpContext.Current.Session["SheetsPath"].ToString();
            }
        }
        public Spreadsheets(string nothing)
        {
        }

        
        public void MakeTable(string RandomNum, string tableName,int NewFile, DataTable da)
        {

            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "SpreadSheets_insert", RandomNum, NewFile, tableName);
            SqlConnection connection = new SqlConnection(ConfigurationManager.ConnectionStrings["SpreadsheetsConnection"].ConnectionString);
            connection.Open();
            string sql = "CREATE TABLE "+ ds.Tables[0].Rows[0][0].ToString()+"__"+tableName +RandomNum+ " (";
            if (ColumnsinFirstRow == false || da.Rows.Count==0)
            {
                foreach (DataColumn dc in da.Columns)
                {
                    string datatype = "";
                    datatype = dc.DataType.ToString().ToLower().Contains("string") ? "varchar(max)" : (dc.DataType.ToString().ToLower().Contains("int") ? "int" : "datetime");
                    sql += dc.ColumnName + " " + datatype + ",";
                }
            }
            else
            {
                if (da.Rows.Count > 0)
                {
                    DataRow dr = da.Rows[0];
                    foreach (object obj in dr.ItemArray)
                    {
                        string datatype = "";
                        datatype = "varchar(max)";
                        sql +=obj + " " + datatype + ",";
                    }
                }
            }
            if (ColumnsinFirstRow)
                da.Rows.RemoveAt(0);
            sql = sql.Substring(0, sql.Length - 1) + ")";
            try
            {
                SqlCommand cmd = new SqlCommand(sql, connection);
                cmd.ExecuteNonQuery();


                using (SqlBulkCopy bulkCopy = new SqlBulkCopy(connection))
                {
                    bulkCopy.DestinationTableName = ds.Tables[0].Rows[0][0].ToString() + "__" + tableName + RandomNum;
                    bulkCopy.WriteToServer(da);

                }

                connection.Close();
                SetSheets();
            }
            catch
            {
                Err = "Your Spread sheet is not valid, may be problem with special chars or empty columns";
                SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "SpreadSheets_errdelete", RandomNum, ds.Tables[0].Rows[0][0].ToString().Replace("F",""), tableName);
                //SpreadSheets_errdelete
            }
          
        }

        public void SetSheets()
        {
            Sheets = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "SpreadSheets_Get_onRandomNo", RandomNum);
        }

        public void FormateSQL()
        {
            SetSheets();
            foreach (DataRow dr in Sheets.Tables[0].Rows)
            {
                if (SQL != null)
                    SQL = SQL.Replace(dr["FileName"] + "." + dr["SheetName"], dr["FileName"] + "__" + dr["SheetName"] + RandomNum);
            }
        }
        public string GetResultSQL()
        {
            try
            {
                Result = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["SpreadsheetsConnection"].ConnectionString, "SpreadSheets_Get_Result", SQL);
            }
            catch (Exception e)
            {
                return "Your query contains errors.";
            }
            return "";
        }

        public void DeleteSession(string Session)
        {
            SqlLibrary.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["SpreadsheetsConnection"].ConnectionString, "SpreadSheets_Delete", Session);
        }

        public string ValidateSql()
        {
            if (SQL != null)
                if (SQL.ToLower().Contains("sys.") || SQL.ToLower().Contains("db_name()") || SQL.ToLower().Contains("system_user") || SQL.ToLower().Contains("update ") || SQL.ToLower().Contains("insert ") || SQL.ToLower().Contains("delete ") || SQL.ToLower().Contains("create ") || SQL.ToLower().Contains("drop ") || SQL.ToLower().Contains("truncate ") || SQL.ToLower().Contains("alter ") || SQL.ToLower().Contains("update\r") || SQL.ToLower().Contains("insert\r") || SQL.ToLower().Contains("delete\r") || SQL.ToLower().Contains("create\r") || SQL.ToLower().Contains("drop\r") || SQL.ToLower().Contains("truncate\r") || SQL.ToLower().Contains("alter\r"))
                    return "Your query contains invalid keywords";

            return "";

        }
        
       

    }
}