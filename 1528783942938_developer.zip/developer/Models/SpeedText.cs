﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Text.RegularExpressions;
using System.Configuration;
using System.Data;
using System.ComponentModel.DataAnnotations;

namespace developer.Models
{
    public class SpeedText : ShivaKumarDAL.Paging
    {
        public string MainText { set; get; }
        public int Starttext { set; get; }
        public int Endtext { set; get; }
        public int NoofRepeats { set; get; }
        public string Result { set; get; }
        public List<HList> Hvlist { set; get; }
        public int RepeatBit { set; get; }
        public int TemplateId { set; get; }
        public int TemplateBit { set; get; }
        [Required(ErrorMessage="Template Name is required to save the Template")]
        public string TemplateName { set; get; }
        public SpeedText()
        {
            NoofRepeats = 1;
            MainText = "";
            Hvalues = new Dictionary<string, string[]>();
            Hvaluesarr = new string[] { };
            Hvlist = new List<HList>();
        }
        public Dictionary<string, string[]> Hvalues { set; get; }
        public string[] Hvaluesarr { set; get; }

        internal void SetDictionary()
        {
            foreach (string val in Hvaluesarr)
            {
                string item = Hvalues.Keys.ToList().SingleOrDefault(m => m == val);
                // if (item == null)
                // Hvalues.Add(val, "");
            }
            foreach (string key in Hvalues.Keys.ToList())
            {
                string item = Hvaluesarr.ToList().SingleOrDefault(m => m == key);
                if (item == null)
                    Hvalues.Remove(key);
            }
        }

        public void GetResult()
        {
            Result = MainText;


            int index = 1;
            Result = Regex.Replace(MainText, "{{##([0-9]+)}}(((?!{{[0-9]+##}}).)*){{[0-9]+##}}", delegate(Match match)
                        {
                            int number = Convert.ToInt32(match.Result("$1"));
                            string text = match.Result("$2");
                            text = Regex.Replace(text, "{{##([^#]+)##}}", delegate(Match matchC)
                            {
                                string textC = matchC.Result("$1");
                                return "{{##" + textC + index + "##}}";
                            });
                            string temp = "";
                            for (int i = 0; i < number; i++)
                            {
                                // temp += text;

                                temp += Regex.Replace(text, "{{##([^#]+)##}}", delegate(Match matchK)
                                {
                                    string Mk = Hvalues[matchK.Result("$1")][i];
                                    return Mk;
                                });

                            }
                            index++;
                            return temp;
                        }, RegexOptions.Singleline);
            Result = Regex.Replace(Result, "{{##([^#]+)##}}", delegate(Match matchK)
                       {
                           string Mk = Hvalues[matchK.Result("$1")][0];
                           return Mk;
                       });

        }

        public string getReplacetext(string text, int number)
        {
            string k = "";
            for (int i = 0; i < number; i++)
            {
                k += text;

            }
            return k;
        }

        public void Placeholders()
        {
            if (MainText != null)
            {
                int index = 1;
                string Fulltext = Regex.Replace(MainText, "{{##([0-9]+)}}(((?!{{[0-9]+##}}).)*){{[0-9]+##}}", m => "@p" + index++, RegexOptions.Singleline);
                List<Match> Single = Regex.Matches(Fulltext, "{{##([^#]+)##}}").OfType<Match>().ToList();
                MatchCollection Multiple = Regex.Matches(MainText, "{{##([0-9]+)}}(((?!{{[0-9]+##}}).)*){{[0-9]+##}}", RegexOptions.Singleline);
                List<Match> MultipleList = new List<Match>();


                foreach (Match m in Single)
                {
                    var v = m.Result("$1");
                    string item = Hvalues.Keys.ToList().SingleOrDefault(iv => iv == m.Result("$1"));
                    if (item == null)
                    {
                        Hvalues.Add(v, new string[1]);
                    }
                    if (Hvlist.SingleOrDefault(it => it.Key == v) == null)
                        Hvlist.Add(new HList() { Index = m.Index, Key = v });
                }
                int i = 1;

                foreach (Match m in Multiple)
                {
                    int rep = Convert.ToInt32(Regex.Replace(m.Value, "{{##([0-9]+)}}(((?!{{[0-9]+##}}).)*){{[0-9]+##}}", "$1", RegexOptions.Singleline));

                    List<Match> MuliplePH = Regex.Matches(m.Value, "{{##([^#]+)##}}").OfType<Match>().ToList().DistinctBy(d => d.Value).ToList();

                    Single.AddRange(MuliplePH.OfType<Match>().ToList());
                    foreach (Match Mph in MuliplePH)
                    {
                        string item = Hvalues.Keys.ToList().SingleOrDefault(iv => iv == Mph.Result("$1") + i);
                        var v = Mph.Result("$1");
                        if (item == null)
                        {
                            Hvalues.Add(v + i, new string[rep]);
                        }
                        if (Hvlist.SingleOrDefault(it => it.Key == v + i) == null)
                            Hvlist.Add(new HList() { Index = m.Index, Key = v + i, MultipleIndex = i, MultipleCount = MuliplePH.Count, Text = v, Rep = rep });
                    }
                    i++;
                }


                Hvlist = Hvlist.OrderBy(a => a.Index).ToList();
            }

        }

        public void save()
        {
            ShivaKumarDAL.SqlLibrary.ExecuteScalar(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Update_CodeGenerator", TemplateId,TemplateName,MainText,HttpContext.Current.User.Identity.Name);
        }

        public void SetTemplateGrid(string username)
        {
            GridDataset = ShivaKumarDAL.SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Grid_Templates", viewrecords, pageno, sortby, username);
            count = Convert.ToInt32(GridDataset.Tables[1].Rows[0]["count"]);
        }

        public void GetTemplate()
        {
           DataSet DS= ShivaKumarDAL.SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_Templates", TemplateId,HttpContext.Current.User.Identity.Name);
           MainText = Convert.ToString(DS.Tables[0].Rows[0]["Template"]);
        }
      
    }

    

    public class HList
    {
        public int Index { set; get; }
        public string Key { set; get; }
        public int? MultipleIndex { set; get; }
        public int MultipleCount { set; get; }
        public string Text { set; get; }
        public int Rep { set; get; }
    }

    public static class k
    {
        public static IEnumerable<TSource> DistinctBy<TSource, TKey>(this IEnumerable<TSource> source, Func<TSource, TKey> keySelector)
        {
            HashSet<TKey> seenKeys = new HashSet<TKey>();
            foreach (TSource element in source)
            {
                if (seenKeys.Add(keySelector(element)))
                {
                    yield return element;
                }
            }
        }
    }
}