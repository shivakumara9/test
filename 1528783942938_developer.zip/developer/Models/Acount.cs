﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ShivaKumarDAL;
using System.Configuration;
using System.Data;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace developer.Models
{
    public class Acount
    {
        [Required(ErrorMessage = "Please enter User Name")]
        [DisplayName("User Name")]
        public string UserName{set;get;}
        [Required(ErrorMessage = "Please enter Password")]
        [DisplayName("Password")]
        public string Password{set;get;}
        [Required(ErrorMessage = "Please enter Confirm Password")]
        [DisplayName("Confirm Password")]
        public string ConfirmPassword {set;get;}
        [Required(ErrorMessage = "Please enter Email")]
        [RegularExpression("\\w+([-+.']\\w+)*@\\w+([-.]\\w+)*\\.\\w+([-.]\\w+)*",ErrorMessage="Please enter valid Email")]
        public string Email{set;get;}
        [Required(ErrorMessage = "Please select Gender")]
        public int? Gender{set;get;}
        public string RegisterIp { set; get; }
        [Required(ErrorMessage = "Please enter above image")]
        public string Captcha { set; get; }
        public String EmailConfirmCode { set; get; }
        public List<Lookup> GenderList()
        {
           return new Lookup().GetLookupOnType("Gender");
        }



        public int validate()
        {

            return SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "ValidateUser", UserName, Crypto.Encrypt(Password, "9kalika9")).Tables[0].Rows.Count;
            
        }
        public int IsUserAvailable()
        {
            DataSet ds=SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetUseravailble", UserName);
            if (ds.Tables[0].Rows.Count > 0)
            {
               return Convert.ToInt32(ds.Tables[0].Rows[0][0]);
            }
            else
            {
                return 0;
            }
        }
        public int Update()
        {
            SqlLibrary.ExecuteNonQuery(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Update_Member", UserName, Crypto.Encrypt(Password, "9kalika9"), Email, Gender, EmailConfirmCode);
            return 1;
        }

        public int SendEmail()
        {
            
           // string con = "Dear " +UserName+ ",<br /><br />Thank you for registering with <strong>devchips.com<b></b></strong><br />You need to validate your email address to complete your registration process. <br />Copy this below varification code and paste it in varification page.<br /><b>Validation Code: <font color=\"darkgreen\">" + emailconfirmcode + "</font></b><br /><br />Regards,<br />Webmaster<br />http://devchips.com";
            string link = "http://www.devchips.com/acount/verify?email=" + Email + "&code=" + EmailConfirmCode;
            string content = "Dear " + UserName + ",<br/>Thanks for signing up for devchips Please <a href='"+link+"'>activate your account by clicking on this link.</a><br/>"
                           + "If your mail client does not support hyperlinks, please copy the following link, paste it in your browser's address bar, and press 'Go':<br/>"
                           + link
                           
                           + "Best Regards,<br/>"
                           + "The devchips Team<br/>"
                           + "www.devchips.com<br/><br/><br/>"
                           + "Please do not reply to this email.";
            if (developer.Models.Email.SendEmail("noreplay@devchips.com", "devchips.com", Email, "noreplay@99web.info", "info@99web.info", "Email Confirmation from devchips.com", content, System.Text.Encoding.ASCII, System.Text.Encoding.UTF8, true, "mail.99web.info", "noreplay@99web.info", "kalikashiva9", 25, "Basic") == "ok")
            {

                return 1;
            }
            else
                return 0;
        }
        public int SendMessage()
        {
            // new SMS().SendSMS("new user has been created, username=" + UserName);
            return 1;
        }
        public int VerifyEmail()
        {
            DataSet ds=SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_EmailConfirmcodeOnEmail", Email,EmailConfirmCode);
            if (ds.Tables[0].Rows.Count > 0)
            {
                UserName = ds.Tables[0].Rows[0]["username"].ToString();
                return Convert.ToInt32(ds.Tables[0].Rows[0]["confirm"]);
            }
            else
                return 0;

            
        }
        public int Sendverificationmessage()
        {
            // new SMS().SendSMS(UserName + "("+Email+") is confirmed");
            return 1;
        }

        public int forgotmypassword()
        {
            DataSet ds= SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetUserDetailsOnEmail", Email);
            if (ds.Tables[0].Rows.Count > 0)
            {
                UserName = ds.Tables[0].Rows[0]["username"].ToString();
                Password = Crypto.Decrypt(ds.Tables[0].Rows[0]["Password"].ToString(), "9kalika9");


                string content = "Hi,<br/>As per your request, we are sending your user id and password to access the services of <a href='http://www.devchips.com'>http://www.devchips.com</a><br/><br/>" +
                    "Your User Id : " + UserName +
                    "Your Password : " + Password +
                    "Visit <a href='http://www.devchips.com'>http://www.devchips.com</a> and login using your user id and password to access all our services." +
                    "Thanks and Regards<br/>" +
                    "<a href='http://www.devchips.com'>http://www.devchips.com</a> Team";
                if (developer.Models.Email.SendEmail("noreplay@devchips.com", "devchips.com", Email, "noreplay@99web.info", "info@99web.info", "Password recovary from devchips.com", content, System.Text.Encoding.ASCII, System.Text.Encoding.UTF8, true, "mail.99web.info", "noreplay@99web.info", "kalikashiva9", 25, "Basic") == "ok")
                {

                    return 1;
                }
            }
            return 0;
        }

        
    }
}