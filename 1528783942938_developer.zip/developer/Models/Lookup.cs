﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using ShivaKumarDAL;
using System.Configuration;
using System.Data;
namespace developer.Models
{
    public class Lookup
    {
        public int LookupId { set; get; }
        public string LookupType{set;get;}
        public string LookupKey{set;get;}
        public string LookupText{set;get;}
        public int RelationId {set; get;}


        
        public  List<Lookup> GetLookupOnType(string lookuptype)
        {
            List<Lookup> lookuplist = new List<Lookup>();
            LookupType = lookuptype;
            DataSet ds=SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetLookup", LookupType, "", "", 0);
            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Lookup l = new Lookup();
                    l.LookupId = Convert.ToInt32(dr["LookupId"]);
                    l.LookupKey = dr["LookupKey"].ToString();
                    l.LookupText = dr["LookupText"].ToString();
                    l.RelationId = Convert.ToInt32(dr["RelationId"]);
                    lookuplist.Add(l);
                }
            }

            return lookuplist;
            
        }

        public List<Lookup> GetLookupOnTypeNRel(string lookuptype, int RelationId)
        {
            List<Lookup> lookuplist = new List<Lookup>();
            LookupType = lookuptype;
            if (RelationId > 0)
            {
                DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "GetLookup", LookupType, "", "", RelationId);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    foreach (DataRow dr in ds.Tables[0].Rows)
                    {
                        Lookup l = new Lookup();
                        l.LookupId = Convert.ToInt32(dr["LookupId"]);
                        l.LookupKey = dr["LookupKey"].ToString();
                        l.LookupText = dr["LookupText"].ToString();
                        l.RelationId = Convert.ToInt32(dr["RelationId"]);
                        lookuplist.Add(l);
                    }
                }
            }

            return lookuplist;

        }

        public List<Lookup> GetLookupOnTypeNRel(string RelLookuptype,string RelationName)
        {
            List<Lookup> lookuplist = new List<Lookup>();
            DataSet ds = SqlLibrary.ExecuteDataSet(ConfigurationManager.ConnectionStrings["DeveloperConnection"].ConnectionString, "Get_LookupOnRelname", RelLookuptype, RelationName);
            if (ds.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow dr in ds.Tables[0].Rows)
                {
                    Lookup l = new Lookup();
                    l.LookupId = Convert.ToInt32(dr["Id"]);
                    l.LookupKey = dr["LookupKey"].ToString();
                    l.LookupText = dr["LookupText"].ToString();
                    l.RelationId = Convert.ToInt32(dr["RelationId"]);
                    lookuplist.Add(l);
                }
            }

            return lookuplist;
        }
    }
}