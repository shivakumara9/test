﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using System.Web.Mvc.Html;
using System.ComponentModel;
using System.Linq.Expressions;
using System.Web;
namespace ShivaKumar
{

    public static class TabsHelper
    {
        /// <summary> 
        /// Renders an HTML form submit confirm button
        /// </summary> 
        public static MvcHtmlString Tabs<TModel, TProperty>(this HtmlHelper<TModel> helper, Expression<Func<TModel, TProperty>> ActiveTabId, TabSettings settgins,string FormId,string Url)
        {
            string Html="";            
            Html += "<ul id='"+Convert.ToString(settgins.TabsName)+"Tabs' class='tabs' style='text-align:" +(Convert.ToString(settgins.TabsAlign).ToLower() == "right" ? "right;" : "left;" )+ "'>";
            int i = 0;
            foreach (Tab t in settgins.Tabs)
            {
                Html += "<li" + (settgins.ActiveTabId == t.TabId ? " class='active'" : "") + " data-tabid='" + t.TabId + "' title='" + Convert.ToString(t.ToolTip) + "'>";
                Html += Convert.ToString(t.Url) == "" ? "<span>" : "<a href='" + t.Url + "'>";
                Html += t.TabText;
                Html += Convert.ToString(t.Url) == "" ? "</span>" : "</a>";
                //Html+="</li>";
                //Html += helper.HiddenFor(s => settgins.Tabs[i].TabId);
                //Html += helper.HiddenFor(s => settgins.Tabs[i].TabText);
                //Html += helper.HiddenFor(s => settgins.Tabs[i].ToolTip);
                //Html += helper.HiddenFor(s => settgins.Tabs[i].Url);
                i++;
            }
            Html+="</ul>";
            Html += helper.HiddenFor(ActiveTabId, new { id=Convert.ToString(settgins.TabsName)+"ActiveTabId"});
            
            Html += "<script type='text/javascript'>";
            Html += "$(document).ready(function () {";
            Html += "$('#" + Convert.ToString(settgins.TabsName) + "Tabs" + " li').click(function(){";
            Html += "$('#" + Convert.ToString(settgins.TabsName) + "ActiveTabId" + "').val($(this).attr('data-tabid'));";
            Html += "$('#" + FormId + "').attr('action','" + Url + "').submit();";
            Html += "setCookie('coo',1);";
            Html += "});});";
            Html += "</script>";

            return MvcHtmlString.Create(Html);
           
        }
    }
    enum TabAlign
    {
        Left,
        Right
    }
     
    public class TabSettings
    {
        public TabSettings()
        {
        }
        public TabSettings(string TabsName,params Tab [] Tabs)
        {
            this.TabsName = TabsName;
            this.Tabs = Tabs;
            if (TabsAlign == null)
                TabsAlign = "Left";
        }
        public string TabsName { set; get; }        
        public string TabsAlign { set; get; }
        public Tab [] Tabs {private set; get; }
        public int ActiveTabId { set; get; }

    }

    public class Tab
    {
        public Tab()
        {
        }
        public Tab(int TabId, string TabText, string Url, string ToolTip)
        {
            this.TabId = TabId;
            this.TabText = TabText;
            this.Url = Url;
            this.ToolTip = ToolTip;
        }
        public int TabId { set; get; }
        public string TabText { private set; get; }
        public string Url { set; get; }
        public string ToolTip { set; get; }

    }
}
