using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace ShivaKumarDAL
{
    public class SqlLibrary
    {
        public static int ExecuteNonQuery(string SqlConnectionstring, string SqlCommand, params object[] Parameters)
        {
            SqlConnection cn = new SqlConnection(SqlConnectionstring);
            cn.Open();
            SqlCommand com = new SqlCommand(SqlCommand, cn);
            com.CommandType = CommandType.StoredProcedure;
            for (int i = 0; i < Parameters.Length; i++)
            {
                SqlParameter sp = new SqlParameter();
                com.Parameters.Add(sp);
                com.Parameters[i].ParameterName = string.Empty;
                com.Parameters[i].Value = Parameters[i];
            }
          int ret=  com.ExecuteNonQuery();
          cn.Close();
          return ret;
        }

        public static DataSet ExecuteDataSet(string SqlConnectionstring, string SqlCommand,params object[] Parameters)
        {
            SqlConnection cn = new SqlConnection(SqlConnectionstring);
            SqlDataAdapter da=new SqlDataAdapter(SqlCommand, cn);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
        
            for (int i = 0; i < Parameters.Length;i++)
            {
                SqlParameter sp=new SqlParameter();
                da.SelectCommand.Parameters.Add(sp);
                da.SelectCommand.Parameters[i].ParameterName = string.Empty;
                da.SelectCommand.Parameters[i].Value = Parameters[i];
            }
            DataSet ds = new DataSet();            
            da.Fill(ds);
            return ds;
        }
    }
}
