create procedure Insert_ReviewComments
@ArticleId int,
@Comment nvarchar(max),
@ReviewerId int
as
begin
INSERT INTO [dbo].[ReviewComments]
           (
           [ArticleId]
           ,[Comment]
           ,[ReviewerId]
		   ,[Reviewedon])
     VALUES
           (@ArticleId
           ,@Comment
           ,@ReviewerId
		   ,Getdate())
End


