
ALTER procedure [dbo].[Get_AllPendingArticles]
as
begin

select [articles].id as ArticleId, title as ArticleName,u.username as SubmitedBy,Updateddate as SubmitedOn
from [dbo].[articles]
inner join [dbo].[Members] as u on [articles].userid=u.id
where statusid=4 order by Updateddate desc
End


