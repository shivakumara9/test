

CREATE procedure [dbo].[GetAllApprovedArticles]
as
begin

select [articles].id as ArticleId, title as ArticleName,u.username as SubmitedBy,Updateddate as SubmitedOn
from [dbo].[articles]
inner join [dbo].[Members] as u on [articles].userid=u.id
where statusid =2 order by Updateddate desc
End


