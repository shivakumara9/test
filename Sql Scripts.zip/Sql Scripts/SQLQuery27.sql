
Create procedure [dbo].[GetAllRejectedQuestions]
as
begin

select [Forum].id as QuestionId, title as QuestionName,u.username as SubmitedBy,Updateddate as SubmitedOn
from [dbo].[Forum]
inner join [dbo].[Members] as u on [Forum].userid=u.id
where statusid =3 order by Updateddate desc
End


