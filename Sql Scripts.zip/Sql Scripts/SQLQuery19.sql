Create procedure GetAllReviewers
as
Begin
select * from roles
end