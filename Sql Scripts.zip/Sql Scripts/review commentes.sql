Create procedure Get_ReviewComments
@ArticleId int,
@UserName nvarchar(1000)
as
begin

select ArticleId,title,Comment,r.username as ReviewdBy from [dbo].[ReviewComments]
inner join [dbo].[Members] as r on ReviewerId=r.id
inner join [dbo].[articles] on ArticleId=[articles].id
inner join [dbo].[Members] as u on [articles].userid=u.id
where ArticleId=isnull(@ArticleId,ArticleId) and u.username=@UserName
order by Reviewedon desc

End


