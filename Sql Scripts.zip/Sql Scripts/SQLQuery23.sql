Create Procedure IsUserOnRole
@UserName varchar(1000),
@RoleName varchar(500)
as
Begin
if(exists(select * from Roles where UserName=@UserName and Role=@RoleName))
Begin
select 1 IsUserOnRole
End
Else
Begin
select 0 IsUserOnRole
End
End
